# Intake prompt for the Milestone 1 planning agent

Plan Milestone 1 — Evidence contract, adapter and fixtures — for this repository. Produce an
implementation-ready plan; do not implement the detector or start OCR work in this planning task.
Inspect the actual repository and preserve existing user changes. Do not create another task or
assign agents unless asked.

## Read first

Read AGENTS.md, README.md (especially section 3.1), PLAN.md, the current evaluation contracts,
and tools/eval-format-tools/README.md. Then read:

- eval/reviews/hkex-2025-48/README.md
- eval/reviews/hkex-2025-48/ready-development.json
- eval/reviews/hkex-2025-48/readiness.r5.json
- eval/reviews/hkex-2025-48/closure-verification-2026-09-10.json
- eval/config/hkex-2025-48.sources.json
- eval/negatives/PLAN.md

PLAN and the current handoff own implementation status. Older delivery-status prose in the frozen
scoring/format contracts is historical. Do not edit hash-bound contracts or reroll the frozen split
as a side effect of planning.

## Settled decisions

1. Milestone 0 is complete: 48 valid records, four owner-approved ready development cases, 44
   pending. One conservative group is assigned dev, with no independent holdout. Headline scoring
   remains UNGATED. Prior approvals do not approve newly generated IR or new fixture annotations.
2. Ignore the OCR engine layer for current development. Use the existing clean and corrupted
   MinerU outputs, unchanged. Do not install, run, host, train or adapt OCR, or require another engine.
3. Build a small translation adapter: selected native artifacts → validated, versioned, persisted
   document evidence IR → main detector pipeline. Downstream code depends on IR, not MinerU fields
   or installation. Clean and corrupted inputs are independent runs; never compare them at runtime
   to discover errors or use the clean counterpart as an oracle.
4. Avoid reading/parsing raw PDFs. Inspect selected native JSON/HTML and existing reviewed evidence
   first. Only inspect necessary PDF pages when a material ambiguity cannot otherwise be resolved;
   record the reason and result. Preserve missing evidence and abstentions instead of manufacturing it.
5. corpus/error_detail.jsonl is immutable error-injector ground truth, gitignored with corpus. Its
   purpose is evaluation preparation, raw-to-canonical provenance and integrity checks. It is not
   adapter input, detector configuration, a prompt source or a relationship-selection oracle. Use
   reviewed canonical annotations for evaluation; raw descriptions are not automatically ready truth.
   Do not scan raw answers to design detector rules. Preserve all 48 records and source hashes.
6. Use DeepSeek-V4-Pro-0813 through OpenRouter for development. Base URL:
   https://openrouter.ai/api/v1; request model: deepseek/deepseek-v4-pro-0813.
   Read the credential from OPENROUTER_API_KEY in the execution environment. A credential was
   supplied in the owner conversation but was not persisted; a new agent must not assume it exists
   in its environment. Never copy it from conversation history into the plan, code, logs or commits.
   Planning does not require a paid model call. Schedule a bounded synthetic capability/identity probe
   before semantic integration; preserve observed provider/model identity and routing settings. The
   owner selected this exact model identifier; availability and served identity have not been probed.
   Historical Flash catalog and direct-API alias evidence do not validate this Pro selection. Do not silently substitute another model if unavailable.

## Investigate and plan

- Inventory relevant existing code and explicitly selected native artifact structures. Use the source
  configuration/manifest as an index; do not glob the corpus as runtime discovery. Determine what
  tables, raw text, spans, IDs, page locations and unresolved regions can actually be recovered.
- Specify the smallest usable IR, manifest and validation rules, stable identities and native-pointer
  provenance. Preserve literal Chinese and distinct occurrences. Geometry is optional when missing;
  define units/origin/rotation only from evidence. Record unsupported layouts and capabilities.
- Keep evidence IR, semantic annotations, comparison plans, results and evaluation metadata separate.
  The adapter translates evidence without interpreting accounting relationships or correcting values.
  Code parses amounts and computes with decimals; model outputs reference IDs/roles/links, not amounts.
- Identify the exact modules/files to add or change, dependencies with licensing review, and ordered
  implementation steps. Prefer standard-library capabilities; avoid services, databases and new engines.
- Plan native-artifact and IR-only input modes. The current audit_inputs interface requires a PDF;
  that is legacy Milestone 0 behavior to change, not a reason to keep reading PDFs. Default runtime
  access must deny PDFs, raw injector metadata, evaluation artifacts and unselected counterpart exports
  or IR, including resolved paths/symlinks. Extend protection to actual prompts and modules.
- Use the four approved cases via ready-development.json for evaluator-owned acceptance examples.
  Their hand-authored operands are not runtime input. Add a small reviewed benign/ambiguous set and
  portable synthetic fixtures. Do not require reviewing all 44 pending cases to start Milestone 1.
- Define observable acceptance checks: source traceability and literal text preservation, malformed
  native inputs, broken IDs/spans, incomplete tables, optional geometry, deterministic replay, schema
  compatibility, and downstream execution with MinerU unavailable and PDFs inaccessible. Separate
  structural validity from evidence fidelity and detector performance.
- Keep OpenRouter client/semantic execution scoped to the appropriate later milestone unless a
  concrete Milestone 1 contract probe is necessary. Provider selection is settled; actual access,
  capability validation and revision limitations remain open implementation evidence.

## Return

Deliver an ordered plan with concrete files/contracts, risks, test commands discovered in the repo,
reviewable acceptance criteria and the first useful implementation slice. State which steps an agent
can execute and which require owner input. Update PLAN.md only as needed to reconcile the proposed
Milestone 1 sequence; leave implementation checkboxes open until demonstrated.

Owner decisions still needed later: dated alert and full-document runtime budgets, fixture acceptance,
and any independently grouped evaluation evidence for holdout claims. OCR provenance/deployment
licensing is deferred unless OCR/end-to-end scope is explicitly reintroduced. Adapter dependencies
still need review. Do not reopen Milestone 0 or claim headline scoring readiness.
