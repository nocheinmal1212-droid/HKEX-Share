# 2026-09-09 — Milestone 0 implementation

- Implemented evaluation-only inventory/import/validation/grouping/review tooling and a runtime-safe
  explicit-input probe. No detector, extraction adapter or model calls were introduced.
- The 48 supplied records are retained in successive immutable intake revisions. Pending does not
  mean retired/excluded. The user remains interim owner; no owner approval has been fabricated.
- All supplied token rectangles matched character-center probes under one-based physical pages and
  top-left PDF-point coordinates. Naive crop extraction included neighboring characters at some
  sites, so character centers provided a more discriminating check. Visual inspection corroborated
  selected sites; logical container/native mappings remain proposed.
- Origin PDF byte hashes differ. Initial page geometry checks falsely compared numeric 0 and 0.0
  as strings; corrected numeric comparison, content/text checks and low-resolution rendering agree
  across all pages. Preserve the original diagnostic and correction. OCR settings equivalence remains
  unverified despite the matching export version strings.
- Conservative grouping places the entire interacting single-report delivery in one group. The
  predetermined hash assigns it to development. No reroll; no untouched holdout or cluster interval.
- Selected-page inspection reveals white redaction patches, typography differences and deleted title
  characters. This is a benchmark artifact risk, not evidence of model detection quality. Controlled
  benign fixtures are planned before any artifact-only chance-performance claim.
- Proposed numeric relationships include the total's rounding uncertainty and source-derived decimal
  values. Remaining context/propagation and human mapping review are explicit; no ready promotion.
- The initial Python audit-hook probe covers actual open/pathlib/io/os.open reads and symlink targets.
  It is not a hostile-code sandbox and cannot certify future native I/O or extractor subprocesses.
- Review evidence, package licenses, model-documentation limitations, budgets and next actions are
  recorded in the evaluation handoff. The next useful step is owner review of the four-case packet,
  followed by a mapping/proposal revision and hash-bound approval for supported development inputs.
- Final local verification: 26 distinct synthetic regression tests passed; formatting and schemas
  passed for the taxonomy and all three retained 48-record revisions. The current revision passes
  raw-source/reference/numeric validation and byte-identical re-import; --require-ready returns 3.
  An attempted salt reroll was rejected before writing. All 788 source hashes/export inventories
  remain unchanged. Expanded initial isolation probes also deny clean native exports and review files.
- Published MinerU 3.2.2 wheel was inspected without installation. Its hash, custom Apache-based
  license conditions and declared backend alternatives are recorded; actual export build, model
  weights and serving dependency closure still need extraction-team attestation. No deployed engine
  or semantic endpoint compliance/parity is claimed. Remote CI has been configured but not run here.

## 2026-09-09 — Owner-approved development readiness and Milestone 0 closure

The user explicitly approved promotion of all four packet cases. Recorded the literal authorization,
packet hash, source-review details, and owner approvals bound to exact pending-record fingerprints.
Completed propagation review from the existing source evidence without fabricating historical injector
settings or causal ordering. Gross profit has linked downstream subtotal edits; no propagated edit was
found within the other three reviewed discrepancy relationships. Numeric relations and their computed
residuals/bounds are unchanged. Full evidence is in evaluation review artifacts, not runtime modules.

Created record, mapping and split revision 3. Four records are ready; all other 44 records remain
unchanged as parsed objects. New split revision only binds approved mapping status; original site/group
assignments, salt, seed and frozen contract hashes are unchanged. Previous revisions and the pending
review packet remain immutable. Native-to-IR adapter correspondence is still Milestone 1 work.

Closing checks: 26 tests passed; formatting/schema checks passed; all 48 canonical records passed
source/reference/approval/numeric validation; approved re-import was byte-identical; all 788 source
hashes and export inventories remained unchanged; initial file-access isolation passed. Milestone 0's
minimum-intake exit is satisfied. Remaining metadata, licensing, budgets and scoring gates retain named
owners. There is still no holdout and headline status remains UNGATED.

## 2026-09-10 — Closure re-verification and status reconciliation

Reverified the minimum Milestone 0 exit: 48 valid records (four approved ready, 44 pending),
26 passing synthetic tests, formatting/schema checks, source-backed validation and byte-identical
approved re-import. Current development-selector hashes and preserved split assignments, salt, seed
and contract hashes pass. Initial isolation again permits two selected files and denies 475 forbidden
files/symlink targets across four Python read methods. Prior visual review remains historical evidence;
PDF rendering and remote CI execution were not repeated. The owned readiness register still supplies
a next action for every unresolved item. See the dated closure-verification artifact in the review folder.

Reconciled stale README implementation claims, PLAN ownership and deferred prerequisites, and the
tooling's historical packet replay instructions. The packet selection binds a canonical JSON fingerprint
of split revision 2, not its file-byte hash; verified with the packet's fingerprint helper. Existing
contracts, approvals, records, source evidence and frozen splits remain unchanged. Contract delivery-status
prose is explicitly identified in README as the pre-intake baseline; current status belongs to PLAN and
the review handoff. No new review approval or publication eligibility is inferred. Milestone 1 can begin;
headline scoring remains UNGATED, with no independent holdout in this bundle.

## 2026-09-10 — Confirmed MinerU-to-IR handoff

The user confirmed that the first evidence IR should be built from MinerU output to separate OCR
from the main pipeline. README previously described MinerU as a possible producer, while PLAN already
required a first MinerU adapter and frozen-IR consumption without MinerU. Reconciled that wording:
existing native artifacts → adapter → validated persisted IR → downstream audit modules. Added an
explicit Milestone 1 replay check with MinerU unavailable. This is a documented decision, not an
implemented adapter or IR. Engine deployment and provenance gaps remain owned prerequisites for
corresponding claims; evidence limitations remain visible and may require abstention. No frozen
evaluation contract or artifact changed. Verified the documentation diff for whitespace and consistency.

## 2026-09-10 — Existing-artifact scope and OpenRouter decision

The user excluded OCR work from current development: consume existing clean/corrupted MinerU
exports as separate runs and avoid raw-PDF reads unless strictly necessary. Updated README, PLAN
and agent guidance. The initial runtime interface still requires a PDF; the Milestone 1 handoff
explicitly plans native-artifact/IR-only inputs and denial of default PDF access. Confirmed gitignore
covers corpus/error_detail.jsonl; it remains immutable injector evidence for evaluation intake, never
runtime or prompt input. Gitignore is not an isolation control.

Selected OpenRouter for development DeepSeek-V4-Flash access. Public documentation confirms base
URL/model slug; its catalog labels the model 0423, so historical direct-API alias evidence cannot
establish served revision equivalence. No authenticated request was made and no credential was
persisted. A secret-free planning handoff specifies environment-based credential access and a later
synthetic capability/identity probe. Readiness revision 4 preserves revision 3 and records changed
scope, provider selection and outstanding work. No frozen split, records or approvals changed.

## 2026-09-10 — Owner changed semantic model to Pro 0813

Reconciled current README, PLAN, AGENTS and Milestone 1 planning handoff to the exact OpenRouter
identifier `deepseek/deepseek-v4-pro-0813`. Readiness revision 5 preserves revision 4 by predecessor
hash and removes inherited Flash catalog claims from the current model entry. Historical logs and
readiness revisions remain unchanged. No endpoint availability/capability probe or authenticated
request was performed. Frozen intake records, approvals and scoring contracts are unchanged.
Validated current model references, readiness JSON/predecessor and documentation whitespace.

## 2026-09-10 — Milestone 1 planning investigation

Expanded PLAN's Milestone 1 into an ordered implementation handoff; implementation remains open.
The repository currently implements intake/formatting and a PDF-required input probe, not an adapter,
IR or detector. Planning read the current handoff and reviewed development selection, then selected
native artifacts through the source configuration/inventory. No PDFs or raw injector records were
opened, no OCR/model calls were made, and no credential was inspected.

Both middle-JSON byte hashes match the frozen inventory. Each has 228 sequential pages with native
dimensions [595, 841]. Walking preproc_blocks plus discarded_blocks found 132 page-local tables,
132 HTML strings and 6,415 HTML cells in each export. An exploratory HTML span-occupancy check
found no holes, overlaps or row-span overflow. This is structural reconnaissance, not reviewed
evidence fidelity or an implemented schema validator.

The important rejected approach is using para_blocks alone: page indices 122–127 contain merged
HTML and four deleted later table bodies. preproc_blocks preserves the page-local fragments.
Do not merge both views as independent facts. Content-list/model exports use other coordinate scales;
native integer dimensions do not establish exact PDF points, rotation or cell geometry. Preserve
native coordinates with explicit unknown frame properties until supported.

The inspected native evidence has literal text, HTML spans, captions/footnotes and page furniture,
but no cell/character boxes or fonts. Reference-currency cells on page index 158 concatenate multiple
numbers; HTML also contains images/equations, and image descriptions are model-generated prose.
These observations motivate raw-fragment provenance and local limitations, not value repair or new
source-error categories. Selected ready-case native candidates still need generated-IR correspondence
and owner acceptance. No prior approval was extended to proposed fixtures.

The next useful implementation is a guarded native-to-IR slice with independently checked text/span
preservation and an IR-only inventory consumer. Keep semantic client execution and arithmetic in
Milestone 2. The existing portable make check passed formatting, schema checks and all 26 tests;
schema discovery covered 192 record instances across four revisions. Full source-backed validation,
PDF fidelity review, remote CI, runtime adapter isolation and detector performance were not tested
in this planning task. Frozen evaluation artifacts and all existing user edits were preserved.

## 2026-09-10 — Milestone 1 implementation and pending handoff acceptance

Implemented the runtime package, versioned evidence/manifest/input/downstream schemas, conservative
MinerU middle-JSON translation, native source spans, source/identity/grid validation, exact-file access
guard, persisted ingestion and IR-only inventory/context replay. Moved audit_inputs out of the evaluator
package and migrated its tests; the old PDF selection is now explicitly rejected. No financial parser,
semantic model call, detector, OCR installation/execution, PDF read or raw-injector-record read occurred.
The user's credential-file fallback authorization was acknowledged but not needed or exercised.

The first native run confirmed that preproc_blocks preserves all 132 page-local table regions; the
paragraph-view cross-page merge remains a recorded limitation. Full independent clean/corrupted runs
each retain 228 pages and 6,415 cells. An evaluator-only traversal matched all 3,314 literal native
content/HTML pointers to their IR sources; the IR additionally retains two unsupported-region JSON
fragments. Clean grids: 129 resolved, 3 partial; corrupted grids: 128 resolved, 4 partial. Inline visual
content stays unsupported. Resolved means HTML occupancy, not PDF fidelity or accounting completeness.

A test-driven refinement added complete source markup spans for blank cells as well as text-fragment
spans; otherwise empty-cell provenance could only be inferred from an ordinal. Identity, parent/page
membership, cell-anchor overlap, geometry absence, exact Unicode/entity preservation, incomplete grids,
resource limits and invalid-input failures remain separate from detector logic. The context builder is
bounded and excludes generated descriptions; actual model prompt isolation remains Milestone 2 work.

Verification: 19 portable evidence tests and all 26 retained intake tests pass. New fault probes reject
broken IDs/spans, overlapping cell positions, wrong IR versions/variants, malformed inputs and hash
changes. Full local checks pass for native pointer completeness, immutable repeat ingestion, IR-only
replay and forbidden-path probes, including symlinks. Runtime access logs show each adapter reads only
its selected native JSON; replay reads only its evidence/manifest. The wheel was built locally without
network, its packaged schemas equal the authority bytes, and installed-wheel replay passed with the
installed adapter directory made unavailable. Canonical evidence/context bytes replay identically.

Saved outputs: runs/milestone1-r1/ (local, gitignored); evaluator review packet and verification summary:
eval/milestone1/reviews/r1/. All four prior ready cases have unique proposed native/IR correspondences
in both variants. Six portable benign/ambiguous fixture expectations and additional evidence layouts
are proposed, not owner-approved. The report escapes source HTML and requests acceptance of the exact
packet fingerprint. Existing intake records, hashes, approvals and frozen split were not changed.

Dependency evidence records the existing runtime closure's packaged MIT notices and native binary
identity. This does not claim a source-level audit of rpds-py's Rust dependency closure or hostile-code
containment by Python audit hooks. The CLI requires a new output directory for each invocation so its
timing/access record cannot overwrite history; low-level equal-byte writes remain idempotent.

Milestone 1 implementation is available; closure remains pending owner acceptance of the new IR
correspondence and fixture labels. No model credential is needed for that review. Semantic execution,
scoring budgets, independent holdout claims and OCR deployment evidence remain later work. Headline
status remains UNGATED. Next useful step: review the concrete handoff, then run the bounded synthetic
OpenRouter capability/identity probe at the start of Milestone 2.

## 2026-09-12 — Authorized cross-model synthetic diagnostic

Owner requested DeepSeek V4 Flash 0731, GLM 5.3 Flash and Gemini 3.8 Flash through the current
probe. Added an explicit diagnostic model argument without changing the designated Pro default,
prompt/schema or call bounds. GLM (DeepInfra) and Gemini (Google AI Studio) passed both cases;
Flash (OpenInference) unexpectedly abstained on the valid total label, so its second case was
not called. Five completed calls; an earlier sandbox network error is separately preserved.
37 local tests passed; saved first requests equal historical Pro's except model ID, fingerprints
verify, and parsed decisions match raw response content. See [probe notes](openrouter-probe.md)
and its linked comparison manifest. The evidence narrows an Ionstream-only hypothesis but does
not separate model, prompt and provider schema effects. Pro integration remains blocked; no
report/PDF inputs were used. Next useful check: bounded prompt-clarity versus schema-mode controls.

## 2026-09-12 — Approved prompt/schema diagnostic

Completed `prompt-schema-v1`: two DeepSeek models × two prompts × two schema modes × three
synthetic cases (24 calls), saved predeclared plans and exact responses. See
[probe notes](openrouter-probe.md) for results and verification links. Original strict cases now
pass unchanged; Pro route is Baidu instead of Ionstream, Flash remains OpenInference with the
same reported fingerprint. Both clarified modes pass all controls. Original no-schema Flash
recognizes the correct ID but emits invalid vocabulary; Pro truncates on two cases at 512 tokens.
Historical Flash reasoning also names the correct ID with invalid action/role while final output
abstains: evidence for investigating schema/vocabulary interaction, not proof of mechanism.
Removing schema also removes vocabulary from the original prompt, an explicit experimental
limitation. All 39 local tests passed; all 24 saved results/fingerprints and planned requests
verified, including historical request equivalence. No report/PDF input. Default model and
integration status unchanged. Next useful experiment is provider-pinned repetitions with both
prompts and negative controls; current one-sample cells cannot establish a stable fix.

## 2026-09-15 — Approved isolated hypothesis fixtures executed

Owner designated DeepSeek/GLM as subjects and Gemini as independent comparison oracle. Completed
all 146 frozen calls (121 subject, 25 oracle) with no retries; retained access errors/timeouts.
[Full report](experimental-fixture-results-2026-09-15.md) links exact requests/responses and
comparison tables. P11 strict passes core and repeated controls on primary Pro/Baidu and
Flash/OpenInference (15/15 each); GLM core 5 pass/4 rate limits, plus a later schema-valid P11
missing-target error against a passing oracle. Model-independent acceptance remains unmet.
Original Pro/Ionstream abstention reproduced twice; P11 positive passes three times. Negative
control failures on Pro/Baidu isolate scope wording as useful; Flash shows repeated-request
variation. Gemini itself has no-schema format/truncation failures. Increasing budget is not a
contract-correct fix. Next useful work: separate GLM target-ID failure from service availability;
a typed target-existence precondition would require a separately versioned pipeline experiment.

Non-invasive observation preserved request bytes and bounded response bytes with no redaction
needed. Transport worker cannot read project evidence, source fixtures, answer key or .env;
bootstrap injects only the credential into a minimal environment. Broad OS read allowlists failed
at interpreter startup before calls; final OS project-data denial plus Python read allowlist and
output-only writes passed 20 real read-denial checks. Original sandbox profiles and launch revision
are retained. 47 local tests passed; all 146 request/response hashes, reviewed fixture preservation,
reported provider names and identical offline evaluation replay verified. No supplied PDF/native/
IR/benchmark data used. Production semantic model and milestone acceptance unchanged.

## 2026-09-15 — Provisional interface-boundary investigation

Owner narrowed current work to deterministic responsibility and task-contract communication,
with Pro as baseline, V4 Flash as primary refinement subject, and V4.1 Flash an optional extension.
These correspond to hypotheses 3/4 in the latest discussion, not the earlier H3/H4 identifiers.
User reports successful Flash reruns; exact environment/prompt records remain unspecified, so
these are qualitative evidence against reliably reproduced failure, not new scored observations.

Code inspection found ID-membership/reference checks but no typed-target precondition in the
synthetic probe. Offline counterfactual review of saved DeepSeek missing-target attempts found
24 dispatches (including five wrong-existing-ID outputs) that a caller-supplied exact missing-target
precheck would avoid. This does not improve intrinsic model accuracy or rewrite historical scores.
New [proposal](interface-boundary-fixture-proposal.md) has 11 offline boundary fixtures and ten
eligible model-contract fixtures comparing existing P11 with concise equivalent wording. A limit
fixture deliberately retains a semantically wrong but structurally valid answer; guards must not
claim to solve interpretation. No guards implemented and no new inference calls made.

V4.1 Flash is listed on OpenRouter. Public endpoint metadata advertises strict output support on
some endpoints, while the page FAQ says response_format is unsupported. Saved metadata/hash and
routing caveat are linked in the proposal; live conformance remains unverified. Proposed execution
uses reviewed answers rather than treating Pro as an oracle, preserves prompt/provider controls,
and keeps model-serving errors and code-blocked opportunities distinct from model accuracy.

## 2026-09-16 — Approved interface-boundary experiment executed

Implemented an experimental typed input/output boundary and executed all 180 frozen synthetic
attempts: 120 Pro/existing V4 Flash base calls, plus 60 V4.1 Flash extension calls. Fresh endpoint
metadata allowed a common Fireworks route with strict schema; previous providers differ, so this
is not exact historical serving replay. [Results](interface-boundary-results-2026-09-16.md) preserve
every request/response and reviewed expectation. Pro baseline is not an oracle.

Pro existing explicit P11: 30/30 pass. Concise wording: 26/30, with two truncations and two normally
completed unexpected abstentions. Both abstentions occur on C06 (requested ID disambiguates two
total labels); B0 passes all three repetitions. Scope wording is a useful next hypothesis, but
the multi-phrase prompt change does not isolate one causal clause. Shorter input did not produce
faster paired passing observations. Retain B0 as the candidate rather than promote B1.

V4.1 Flash passed 30/30 in each arm. All 60 existing V4 Flash calls returned upstream HTTP 429;
its primary-subject comparison remains unassessed. No retry, provider switch, replacement call,
prompt repair or budget rescue occurred. Proposed next work: separately frozen existing-Flash
rerun on an available pinned endpoint, then scope-only controls with new reviewed examples.

All 11 offline deterministic fixtures and 55 local tests passed. The guard intentionally accepts
D09's structurally valid semantic error; live C inputs are all eligible, so no pass-rate gain is
claimed from filtering. Boundary implementation stays under tools/experiments, outside production.
Twenty protected-read denials in both preflight and live isolation records, all 180 start/outcome
records, reviewed input/expectation preservation, 90 prompt-only pairs, byte hashes and identical
offline evaluation replay verified. No credential redaction needed. No supplied PDFs/native/IR/
benchmark inputs used. API-reported cost USD 0.042627614; 60 records lack cost. Production model,
R4 approval, and milestone acceptance remain unchanged; synthetic results do not establish full
pipeline or financial interpretation accuracy.

## 2026-09-17 UTC — Independent model-interface review

[Review and decision](model-interface-independent-review-2026-09-17.md): all 55 handoff links
resolve; 388 recorded file hashes match (synthetic PDF-named sentinel deliberately skipped).
Independently graded all 180 latest raw attempts against the ten reviewed lexical answers;
verified 90 prompt-only pairs and exact saved evaluation replay for both September 15/16 runs.
The 55-test portable suite passes, including all 11 deterministic fixtures. Explicitly mapped
historical GLM call-120 to a typed missing-target request and observed zero stub calls, preserving
the original wrong answer. Reproduced the 24-case DeepSeek counterfactual without changing scores.

Decision: retain B0 for lexical diagnostics and adopt the deterministic behaviors in the first
real semantic operation; defer promotion of the experimental helper. It accepts input exceeding
the current context budget and propagates transport timeouts without a result. Its `{id,text}`
projection also lacks the evidence context's provenance/content-state/limitations. These scope
gaps do not invalidate the frozen experiment. Define a real operation's prerequisites, bounded
selected evidence and persisted dispatch outcomes together, then verify that path. B0's
no-context-needed clause is lexical-only, not a financial relationship instruction. Existing-Flash
provider comparison is still needed to assess Flash, but does not gate Pro's own implementation.
Prioritize completeness/context ablations and actual failure/persistence fixtures next; proposed
interpretation fixtures remain unexecuted. No production code, source fixtures, historical run,
model selection, approval or scoring status changed; no model calls or corpus/credential reads.

## 2026-09-17 UTC — Owner approved review decisions; next fixtures prepared

Owner response was “Approved.” Recorded acceptance of the independent review's decisions while
retaining deferred production integration. Prepared the [direct-contributor proposal](direct-contributor-fixture-proposal-2026-09-17.md):
14 authored logical interpretation cases and 20 unexecuted dispatch/failure scenarios. Inputs
and evaluator expectations are separate; new exact expected labels remain proposed, not covered
retroactively by approval. The offline checker verifies reference/control consistency only.

Selected first operation: identify nearest direct addends of an explicitly targeted expense
total. Models return IDs and labels, with no financial amounts or coefficients. Nested subtotals,
memo rows, lost relationship evidence, missing contributors, context conflicts, local unknown
units and unrelated limitations are distinguished. Shared unknown units need not prevent a
supported local role relationship; they can still block later arithmetic/conversion. Actual
amount-invariance fixtures remain uninstantiated, because the logical set has no amount cells.

Persistence investigation found a compatibility concern: M1 stage-failure only permits selection,
adapter and consumer, while IR replay binds the full schema hash inventory. Prefer a separately
versioned semantic-attempt artifact rather than silently widening the M1 schema and invalidating
saved IR. No schema/runtime change made. Next useful work is independent expectation review,
conversion to the existing synthetic evidence/IR workflow, then real offline dispatch/persistence
tests. No semantic fixture, failure scenario, live model experiment or production path executed.

## 2026-09-17 UTC — Direct-contributor tests executed; verdict recorded

User authorized execution and then explicitly authorized root `.env` access when the key was absent
from the environment. Bootstrap injected only OPENROUTER_API_KEY into the isolated worker; no key
was logged or persisted. [Results](direct-contributor-results-2026-09-17.md) preserve the frozen
42-call Pro/Fireworks experiment: 31 full passes, one unsupported selection, five timeouts and
five truncations. All seven positive cases passed 3/3. S11 ambiguous group/company scope produced
one wrong selection and two truncations; S08 period conflict produced one timeout and two
truncations. Four truncations have null content/all 2048 tokens reported as reasoning; the fifth
contains partial JSON with 2032 reasoning tokens. Partial abstention text earns no semantic pass.
Do not attribute these incomplete responses to a particular internal cause or infer model incapability.

Implemented only an experimental logical-source dispatcher with request/response persistence and
distinct boundary outcomes. All 20 authored scenarios passed in 30 expanded subcases/controls;
four plausible implementation mutations were detected. Isolated frozen-response replay caught an
own-request readback omitted from the exact file allowlist; fixed that precise permission and added
a regression. Full suite: 61 tests pass. Ten protected reads denied in each live preflight, live
launch, and isolated offline replay. Live worker remains transport-only; no production IR path or
source-amount invariance was tested. Exact evaluation replay and independent raw tally agree.

Preserved setup failures: live preflight needed an absolute interpreter/staging cwd; offline replay
needed the project virtual environment; its next launch exposed the missing own-request read
permission. The initial independent verifier overgeneralized null truncation content from earlier
responses; call-040 disproved it. Corrected the verifier without changing original observations or
grading. Recorded code hashes, raw files, counters, cost and limitations in the new run. Original
prepared fixture/expectation files and M1 schemas remain unchanged. Same-agent review is not an
independent human validation of the new labels.

Verdict: effective diagnostic/regression suite; insufficient production acceptance evidence. Keep
Pro and explicit task wording, investigate referenced-context interpretation versus code-based
compatibility separately, and freeze any budget-only experiment separately from the completed S11
semantic error. Actual IR integration, amount invariance and independent expectation review remain
the next substantive gaps. No production model path or scoring milestone was marked complete.

A final exploratory write-timing probe exposed a missed case: the store writes result bytes and
then raises OSError. Dispatch returns persistence_failure, but replay accepts the leftover valid
JSON as structure_accepted. Original D16 faults occur before writing, so 30/30 planned subcases
and 61 unit tests pass despite this failure. Saved the failing observation and standalone reproducer;
did not change the frozen dispatcher version or hide the failure in the original pass count.
This unresolved completion-contract defect blocks dispatcher promotion and should be fixed with
partial-write/late-error/interrupted-commit regressions before additional integration claims.

## 2026-09-17 UTC — Late-write/replay defect fixed in experimental v2

User prioritized the late-write/replay defect. Reproduced it in a fresh directory before changing
anything: v1 dispatch reports persistence_failure while replay accepts the leftover result. Kept
v1 implementation and frozen runs unchanged; all eight recorded implementation hashes still match,
and the original evidence verifier/exact evaluation replay pass.

The [v2 contract and results](direct-contributor-persistence-fix-2026-09-17.md) require a final
completion record binding every saved artifact. Result bytes alone cannot commit. Write, flush,
file fsync, close and readback must succeed for all dependencies before publishing completion.
An error during completion publication is commit_unknown, since complete bytes can precede a
reported error; replay resolves it without resending. Missing/invalid completion means incomplete.
Claimed source identity and actual snapshot hash are separate so rejected inputs remain replayable.

42/42 fault-timing cases and 72 total tests pass. Additional tests cover fsync/readback failure,
altered/missing dependencies, malformed inventories, refused reuse, terminal outcomes and no implicit
v1 migration. A result-only replay mutant is detected. Initial mutant testing exposed a runner
KeyError on an empty replay object; changed comparison to record it as a failed case, preserving
expectations. Saved isolated v2 replay shows six denied protected reads, one stub call and no network.

Use v2 for new experimental persistence work; historical v1 tooling remains unchanged. No production
module/schema, corpus evidence, credential access or model call was involved. OS-kill/power-loss
durability and concurrent writers are untested/out of scope. Production selected-IR integration,
source-amount invariance and independent semantic expectation review remain open; the original
semantic failures do not disappear when persistence is fixed.

## 2026-09-17 UTC — First connected live v2 attempt run

User authorized live calls through the fixed dispatcher. Added an isolated live adapter that
builds the outbound request from the actual dispatched projection, verifies its frozen hash,
and passes real HTTP outcomes into unchanged v2 validation/persistence/replay. Frozen one pass
of S01–S14 plus a live S01 late-result-write injection, with unchanged prior prompt/wire requests,
Pro/Fireworks, 2048 tokens, 30-second deadline, zero retries/fallbacks and one concurrent call.

[Results](direct-contributor-live-v2-results-2026-09-17.md): all 14 ordinary attempts commit and
replay exactly. S03 returns the correct direct children and S04 correctly abstains for missing
evidence; twelve other ordinary cases receive upstream shared-pool HTTP 429. The live fault probe
also receives 429, then correctly returns persistence_failure/replay incomplete with no completion
record. Thus 15/15 persistence expectations pass but only 2/14 ordinary semantic cases are usable.
A successful live answer followed by the late-write fault remains untested. No adaptive reruns,
provider switch or prompt/budget changes were made. Reported usage cost is USD 0.00690096; thirteen
HTTP-error costs are unknown.

Outer sandbox initially blocked launching sandbox-exec; escalated zero-call preflight succeeded
with the worker sandbox retained. Preflight and live launch each deny twelve protected reads.
Only the approved bootstrap reads root .env; worker credentials remain environment-only. Five new
adapter tests plus prior tests yield 77 passes. Fresh-process replay, raw validation and wire
hashes agree; original v1 and fixed-v2 code remains unchanged. This is the first connected live
logical-fixture path, not real IR or a completed financial audit pipeline. Next live check should
freeze availability recovery separately; production integration and prior semantic gaps remain open.

## 2026-09-17 — Independent bounded API selection

[Selection report](independent-model-selection-results-2026-09-17.md): verified all eight exact owner candidate IDs plus Gemini-3.8 Flash oracle against fresh OpenRouter metadata and live responses. Replayed historical hashes/evaluations and retained Pro's prior wrong-scope failure. New isolated v2 comparison made 46 calls: 31 common-screen attempts, six oracle-only confirmation calls, nine separate explanations. Reported cost USD 0.089131708; ten failed calls have unknown cost. All 46 completions replay; portable suite 82 tests passes. No deployment designation or milestone change.

No deployment candidate advanced: Kimi/Pro timeouts and five no-HTTP transport errors limited seven candidates; GLM-5.3/Morph completed but selected incompatible/unknown-context contributors four times. Generic transport errors cannot establish provider-side cause. V4 Flash 0731/OpenInference and V4.1 Flash/DeepInfra each now have two source-correct controls; they remain distinct and insufficiently assessed. GLM Flash/Wafer omitted required header citations despite correct contributors. MiniMax's two correct, fast controls justify further testing, not a fallback role.

Minimal-overhead synthetic linked-header contrastive pair was frozen before answers; only Gemini qualified to run it, passing both cases twice and S11 twice. It is not real IR or candidate confirmation. Diagnostic sample had three 429s; four of six completed explanations used limitation metadata addresses outside evidence-item IDs. Excerpts existed in source; citation namespace needs care. Explanations did not change scores, and sampling omitted GLM's four later unsupported selections. No automatic cascade measured or recommended.

Next useful check: separately freeze V4 Flash and V4.1 Flash on S08/S11 with safe exception-kind recording, then earn further confirmation through source-correct context decisions. Do not interpret the transport-limited screen as model incapability or oracle agreement as ground truth. Immutable design, keys, requests, raw responses, diagnostics, hash inventory and replay are under `runs/milestone2/model-selection-2026-09-17/` (ignored local artifacts); new tools remain experimental. No raw PDFs, OCR, counterpart or benchmark answers entered inference.

## 2026-09-17 — Approved Flash context discrimination

[Follow-up report](flash-context-check-results-2026-09-17.md): the approved four core calls compared exact V4 Flash 0731/DeepInfra and V4.1 Flash/Together, then continued only V4.1 under the frozen 2/2 advancement rule. V4.1 passed S08/S11 and all four conditional S09/S10/H01/H02 cases: six source/reason/support passes, one selection and five abstentions. Prefer that exact configuration for the next controlled PoC work; no deployment designation or automatic cascade changed.

V4/DeepInfra selected an unsupported Group/Company-ambiguous occurrence on S11. S08 reached HTTP 200 headers but timed out reading the body at 60 seconds; the new fixed-category transport classification distinguishes this from failure to connect, without claiming an internal cause. Its explanation truncated; no usable diagnostic answer. Two V4.1 conflict explanations had valid IDs/excerpts; no initial score changed. V4 reported reasoning-token counts exceeding completion counts twice; retain unreconciled usage, not inferred reasoning shares.

Eleven calls total, USD 0.015112560 reported and one unknown-cost timeout. All eleven v2 completion records replay; all 413 prior inventory hashes match; 86 portable tests pass. First zero-call preflight failed because Python -I excluded the staging import path; preserved it and created r2 with an explicit trusted bootstrap and identical wire requests. Three r2 preflights/live batches each denied 14 protected reads. Evidence and immutable plan are in `runs/milestone2/flash-context-check-2026-09-17-r2/`; earlier failed preparation remains in the unsuffixed directory. No PDFs, OCR or production IR entered this fixture test. Next useful evidence is a small independently reviewed real-IR slice and same-route positive/missing-evidence controls, not production promotion from six correlated logical examples.

## 2026-09-18 — Provisional model policy reconciled; selection experiments closed

Owner approved [Gemini-primary / V4.1-research reconciliation](model-policy-reconciliation-2026-09-18.md).
README section 4 now owns the policy: `google/gemini-3.8-flash` / Google AI Studio supplies validated
operational interpretations; `deepseek/deepseek-v4.1-flash` / Together receives independent research
copies through OpenRouter. Research outputs never feed audit decisions or serve as fallback. Gemini
is not ground truth. AGENTS/README precedence notes tell future agents how to resolve overlooked
model contradictions without rewriting historical evidence. PLAN closes model selection but keeps
paired runtime integration, source validation and business error budgets open. No production code
was wired, no API calls were made, and no new model-selection experiment is scheduled.

The provisional integration plan requires shared evidence/contract inputs, separate v2 completions,
bounded research progress, explicit missing pairs and tests proving that research-output changes
cannot affect accepted annotations/plans/findings. Source-correctness evaluation stays independent
of model agreement. This policy is an owner-selected development direction, not proof of Gemini's
superiority or production sufficiency. Current semantic scope is API-only.

Commit separation and provenance:

- `2584415` — frozen diagnostic fixtures and their evaluator/runtime boundary documentation.
- `fcd40f0` — existing experimental harnesses and ten regression-test modules, separate from fixtures.
- `2c50596` — 1,934 closed-run files, dated reports and model-only historical notes; raw failures,
  failed preparation, expectations and response hashes are preserved. `/runs/` remains ignored for
  future outputs. The two PDF-named denial markers are synthetic strings from preparation code,
  not report PDFs; no raw corpus was added.
- The accompanying `docs(models): reconcile provisional primary and research policy` commit contains
  the active guidance, reconciliation plan and this closure entry. Earlier Milestone 1 review changes
  and unrelated ignore-file edits remain uncommitted; shared documentation was staged by scope.

Verification: all 86 workspace tests pass. A clean export of the staged experiment tree passes all
79 included tests; the other seven belong to pending Milestone 1 review work. Read-only replay from
that export succeeds for lexical/interface fixtures, original direct contributors, connected live
v2, all 46 model-selection completion records and all 11 Flash-follow-up records. All 536 final
inventory hashes remain unchanged. Credential-pattern checks of 1,948 staged non-PDF archive/note
files, including decoded response bodies, found no matches; no credentials were printed or added.
Staged whitespace checks pass. New documentation file links resolve. Three pre-existing core links
to missing `AGENTS_template.md` / `README.original.md` remain unrelated documentation debt; they
were not silently described as passing. The first clean-export Make invocation needed its Python
path quoted because the workspace path contains spaces; the direct equivalent test command passed.

The bounded model-decision investigation is closed. Remaining work is implementation and validation
of this provisional policy, not automatic promotion, a new tournament or completion of the pipeline.
