# Model-interface investigation: independent review handoff

Prepared 2026-09-16. This document summarizes evidence and candidate decisions; it does not authorize
production integration, select a replacement model, or approve further live experiments. The next
reviewer should independently decide what to implement, what needs another experiment, and what
the evidence cannot establish. Existing raw records and reviewed expected answers remain unchanged.

## Decision context

The objective is a dependable, replaceable semantic-model interface. The conversation began with
a tiny synthetic total-label probe that returned a schema-valid but incorrect abstention. The user
questioned intrinsic model capability, insufficient evidence/prompt clarity, serving glitches,
and unnecessary pipeline complexity. Later work focused on two hypotheses:

- **Conversation hypothesis 3:** deterministic responsibilities, especially target-ID existence,
  are unnecessarily delegated to the model. Check them in code before dispatch and retain the
  original model-only failures.
- **Conversation hypothesis 4:** the task contract does not communicate selection rules and
  sufficient evidence reliably. Compare explicit wording with a shorter proposed equivalent.

These numbers are distinct from **H1–H6 in the earlier experiment**, where H3 means schema handling
and H4 means serving/repeatability. Do not conflate the two numbering systems.

Current recommendation for review: carry forward the deterministic boundary behaviors as
implementation candidates; retain the existing explicit P11 wording as the prompt candidate;
do not adopt the concise B1 wording on current evidence. The existing V4 Flash comparison still
needs usable observations. None of this establishes that the overall audit pipeline is infeasible
or that open-source models are inherently incapable.

The most recent roles are Pro as baseline, existing V4 Flash as primary subject, and V4.1 Flash
as an extension. Earlier GLM/DeepSeek runs used Gemini as an independent comparison oracle.
Reviewed expected answers are authoritative in both phases; neither Pro nor Gemini is ground truth.

## Experiments and findings

| Phase | Design and observed results | Interpretation |
|---|---|---|
| Initial probe, Sep 11 | Pro `deepseek/deepseek-v4-pro-0813`, reported Ionstream. Given `field-one: 總計`, `field-two: 收入`, returned `abstain` with null ID/role instead of selecting field-one. HTTP 200; second case not called after failure. | Credential access succeeded. Output structure passed; decision failed. One observation does not identify cause. |
| Model comparison, Sep 12 | Same request except model ID. V4 Flash/OpenInference unexpectedly abstained; GLM/DeepInfra and Gemini/Google AI Studio passed positive and missing-target cases. Five network-enabled calls. | Weakens an Ionstream-only explanation; model and provider differences remain confounded. |
| Prompt/schema diagnostic, Sep 12 | 24 calls: two DeepSeek models × original/clarified wording × strict/no API schema × three cases. Clarified wording passed all six cases per model. Original strict cases also passed unchanged. Original no-schema showed invalid vocabulary or truncation. | Prompt/output-contract interaction is plausible. Removing schema also removed vocabulary from the original arm; not a pure decoding experiment. |
| Hypothesis fixtures, Sep 15 | 146 frozen calls: 121 subject and 25 Gemini oracle. P11 strict core plus scheduled repetitions passed 15/15 each on Pro/Baidu and V4 Flash/OpenInference. GLM had service gaps and a later schema-valid missing-target error. Original Pro/Ionstream positive abstention reproduced twice; P11 positive passed three times. | Explicit vocabulary and scope are useful candidates; no universal guarantee. Provider-associated and within-route variation observed, without an isolated internal cause. |
| Interface boundaries, Sep 16 | 11 offline deterministic fixtures; 180 frozen live attempts: ten eligible cases × two prompts × three repetitions × three models, all pinned to Fireworks. | Separates host validation from interpretation. Existing V4 Flash availability prevented its live comparison. |

Sep 16 results:

| Model | B0: existing explicit P11 | B1: concise proposed equivalent |
|---|---|---|
| `deepseek/deepseek-v4-pro-0813` | 30/30 passed | 26 passed, two unexpected abstentions, two truncations |
| `deepseek/deepseek-v4-flash-0731` | 30 HTTP 429 errors | 30 HTTP 429 errors |
| `deepseek/deepseek-v4.1-flash` | 30/30 passed | 30/30 passed |

All 60 existing V4 Flash errors reported upstream Fireworks rate limiting. They are availability
failures, not 60 incorrect model answers. No provider switch or replacement calls occurred.
V4.1 is a separate extension, not a fallback that fills those missing observations.

On Pro, C06 asks to classify ID `b` while both `a` and `b` say `總計`. Targeted classification has
an unambiguous target even though global unique selection would be ambiguous. B0 passed all three
repetitions; B1 truncated once and abstained twice. The two abstentions finished normally with
`finish_reason=stop`, `refusal=null`, and 121 completion tokens. Their exact content is
`{"action":"abstain","evidence_id":null,"role":null}`. This is a task decision to make no
selection, not a recorded refusal. A refusal is a separately detected refusal response;
truncation is an incomplete output; HTTP 429 is a service error. Preserve these distinctions.

The two Pro B1 truncations had null content, `finish_reason=length`, and all 512 completion tokens
reported as reasoning tokens. One is C06 and one C05. They establish failure under that budget,
not an incorrect final semantic answer. A higher budget was not tested in this phase.

For paired passing observations only, B1 saved a median 65 prompt tokens on Pro and V4.1 but used
30 and nine more completion tokens respectively. Median latency increased by 0.533 s and 0.163 s.
These small, potentially cached samples provide no speed justification for B1. Multiple phrases
changed together, so a particular clause cannot yet be identified as causal.

## Hypothesis assessment

| Hypothesis | Evidence and present assessment | Outstanding discrimination |
|---|---|---|
| Models inherently lack the necessary capability | DeepSeek succeeded on varied small cases with explicit wording; failures vary with prompt/route. General incapability is unsupported. | Broader, independently reviewed interpretation tasks with realistic evidence needs. |
| Pipeline/query is overcomplicated | Shortening wording reduced input tokens but worsened Pro outcomes. Does not support shortening this prompt indiscriminately. | Isolate unnecessary responsibilities or clauses rather than treating length as complexity. |
| Deterministic checks belong in code (conversation 3) | D01–D11 prove exact ID/structure behaviors with call spies. Historical GLM error and DeepSeek counterfactual expose avoidable dispatches. | Map these behaviors into real request, dispatch, and persisted result contracts; verify the actual runtime path. |
| Insufficient task-contract communication (conversation 4) | P11 passes many controls; concise B1 loses Pro behavior on target scope. | Scope-only ablation, targeted-versus-global operations, novel reviewed examples. |
| Output vocabulary/schema interaction (earlier H1/H3) | Original no-schema outputs sometimes use correct ID with invalid action/role. Explicit P11 works in both modes in sampled DeepSeek cases. | Same exact textual vocabulary with schema toggled, enough repetitions to separate variation. |
| Excessive evidence requirements (earlier H2) | Explicitly stating that label text is sufficient helps define the small task; no amounts/table needed for this fixture. | Separate lexical classification from actual relationship/evidence sufficiency tasks. |
| Provider/serving variation (earlier H4) | Ionstream versus Baidu associations, within-Flash variation, and Fireworks rate limits. | Provider-pinned, counterbalanced runs; fresh metadata and preserved identities. Provider names do not attest weights. |
| Completion budget (earlier H5) | Some failures truncate; others normally complete incorrectly. Earlier 512→2048 no-schema tests did not yield a contract-correct fix. | Separate a budget-only experiment for truncations; do not attribute completed abstentions to token exhaustion. |
| Basic language or ID binding (earlier H6) | P11 passes Chinese/English and ID/order transformations on primary DeepSeek routes. | More diverse labels and transformations; no market-wide language-accuracy conclusion. |

The user independently reran Flash successfully in other environments. Exact prompt/request/provider
records were not supplied, so this is qualitative evidence against assuming a reliably reproduced
failure, not an additional scored sample.

## Deterministic fixtures actually executed

The experimental request is `{operation, target_id, evidence:[{id,text}]}`. `classify_target`
requires a caller-supplied exact target; `select_unique_total` requires a null target. No model or
regex extracts a target from arbitrary prose. Code validates structure and existence, renders
the instruction, and validates output fields/IDs. It does not recognize total-label meaning.

| Fixture | Required behavior, verified offline |
|---|---|
| D01 missing target | Retain precondition abstention; zero transport calls. |
| D02 duplicate IDs | Reject input; zero calls. |
| D03 empty evidence | Retain precondition abstention; zero calls. |
| D04 existing total target | One stub call; accept correct target output. |
| D05 existing non-total target, total elsewhere | One stub call; accept the model's correct abstention. Existence alone does not establish a role. |
| D06 output selects a different existing ID | Reject output; do not remap it. |
| D07 output selects an unknown ID | Reject output; preserve the response. |
| D08 abstention with nonnull ID/role | Reject inconsistent output; do not silently normalize it. |
| D09 structurally valid semantic error | Accept structure but independently mark the answer semantically wrong. Deliberate limit fixture. |
| D10 case-sensitive ID mismatch | Treat target as absent; zero calls; no case folding/fuzzy matching. |
| D11 required typed target missing | Reject input; zero calls. |

All 11 passed. These are deterministic tests with stubs and call counters, not 11 successful live
model answers. Seven boundary test methods also cover malformed inputs, unchanged payloads,
mutation of the transport payload, literal IDs, and preservation of invalid outputs. All seven
were rerun successfully in the latest follow-up. The full suite passed 55 tests at completion.

An offline historical counterfactual identified 24 DeepSeek missing-target attempts that a typed
precheck would prevent: 13 correct abstentions, five wrong selections, one truncation, three HTTP
errors, two timeouts. It assumes the caller supplies `field-missing` as a typed target. It does
not alter historical scores or measure improved intrinsic accuracy. It covers DeepSeek, not GLM.
Separately, GLM call-120's original wrong selection is preserved and its raw-response/record hashes
were rechecked against the saved evaluation in the latest follow-up.

## Interpretation fixtures actually executed

| Fixture | Reviewed interpretation requirement |
|---|---|
| C01 | Select the unique Traditional Chinese total label. |
| C02 | Abstain when neither supplied label names a total. |
| C03 | Abstain on two totals for global unique selection. |
| C04 | Classify the requested total target despite a non-total distractor. |
| C05 | Abstain for a non-total target despite a total distractor. |
| C06 | Classify the requested total target even when another total exists. |
| C07 | Preserve selection under evidence reorder with IDs unchanged. |
| C08 | Follow meaning under renamed/rebound IDs. |
| C09 | Select the English total label. |
| C10 | Select the Simplified Chinese total label. |

All C requests passed the same precheck during offline preparation. Frozen requests were then
sent by a separate transport-only worker. Model results were graded against reviewed expectations,
and output postconditions were applied offline without repair. Thus the live run is not proof
that a production dispatcher invokes the new boundary correctly. All 90 model/case/repetition
pairs differ only in system wording; schema ID enums are sorted independently of evidence order.

## Isolation, reproducibility, and limits

The Sep 15/16 workers received only frozen request bytes with opaque IDs, not evaluator answers
or source fixtures. macOS denied project-file data; a Python audit allowlist restricted reads
after imports. Writes were limited to responses and device output. A bootstrap injected the
authorized key as `OPENROUTER_API_KEY` into a minimal environment; the worker could not read `.env`.
Twenty protected-read checks used both pathlib and os.open against the key, fixture, credential
file, README, and six synthetic sentinels. The sentinel called `corpus.pdf` is invented text,
not a supplied PDF. This is isolation for a trusted transport worker, not a general hostile-code
sandbox or a verified production-runtime guard.

Every conversation was fresh; calls were sequential, bounded, and saved without retries,
fallbacks, adaptive wording, output repair, or explanation requests. Sep 16 used strict schema,
temperature zero, 512 completion tokens, 30-second deadlines, and 128-KiB response bounds.
Request/response hashes, source fixtures, all start/outcome records, and exact offline evaluation
replay were verified. No credential redaction was needed. Cache state, provider preprocessing,
actual weights/revision, and statistical independence remain unverified. Three repetitions per
case are insufficient for a high-accuracy service guarantee.

These lexical tasks are materially narrower than real pipeline work: they omit multi-row context,
period/unit/entity compatibility, accounting links, completeness, extraction ambiguity and
comparison planning. Their interface can nevertheless be sensitive to prompt/schema/budget
choices. No scalar difficulty equivalence to the full pipeline was measured. No supplied PDFs,
OCR-quality assessment, native report data, evidence IR, or benchmark ground truth entered these
experiments. R4 approval and production acceptance were not changed.

## Candidate decisions for the independent reviewer

1. **Consider adopting deterministic behaviors and regression fixtures.** Tests already live
   under `tests/` and run in `make evidence-check`; the boundary implementation remains under
   `tools/experiments/`, outside `src/`. Existing `pipeline_contracts.py` checks downstream
   reference membership, but is not a semantic dispatcher and does not implement the typed-target
   precondition. Choose the correct owning contract/module; avoid duplicating validators or
   importing experiment definitions/expected answers into runtime. Define how rejected input,
   precondition abstention, model abstention, invalid output, and transport failure persist in the
   real result ledger. Test actual zero calls and persisted provenance on that path, including a
   replay of the GLM missing-target request mapped explicitly to the new typed contract. Preserve
   the old model-only failure. Do not silently turn structural acceptance into semantic success.
2. **Defer concise-prompt adoption.** Keep B0 as a candidate, not a proven universal solution.
   A new Flash availability run and a scope-only comparison would address different uncertainties;
   do not combine them into an unplanned rescue of old results. Freeze fresh call limits, routing,
   expectations and failure accounting before any live run.
3. **Require broader acceptance before real semantic integration.** Derive evidence requirements
   from actual operations, review new fixtures independently, and keep scoring/split rules and
   production isolation intact. No fallback, fine-tuning or model replacement follows automatically
   from these tiny tests. Pro remains the designated production semantic model.

Possible new fixtures/hypotheses, **not yet executed**:

| Candidate | Small discriminating test and observable expectation |
|---|---|
| Targeted/global scope is conflated | Same two-total evidence, switch only typed operation and instruction. Targeted case selects the requested total; global unique selection abstains. Add new IDs, target positions and independently reviewed labels. |
| Serializing a typed target back into prose weakens the contract | Compare exact structured operation/target fields with current deterministic prose rendering, holding prompt semantics/schema/settings fixed. Expected answers identical; no interpretation of arbitrary prose on the host. |
| Irrelevant distractors interfere with targeted classification | Hold requested text/ID fixed while adding, reordering and changing irrelevant labels; expected target decision unchanged. Do not extrapolate removal of context to accounting tasks that require it. |
| ID encoding leaks into task instructions | IDs with spaces, quotes, Unicode and instruction-like text; require literal membership and target binding. Define permitted ID domain first. Current renderer concatenates IDs into prose. |
| Integration bypass or mutation defeats prechecks | Drive the real dispatch path with invalid input, mutate a payload after validation, and inject wrong-target output. Assert call count, immutable scope, unchanged raw response and retained ledger state. |
| An abstention is valid syntax but an incorrect decision | Pair supported targets with genuinely unsupported evidence and missing targets. Keep semantic wrong abstention, model refusal, host precondition abstention and service failure distinct. |
| Input savings cause more completion work | Matched prompt pairs with token/latency accounting and a separately declared budget arm; preserve truncations and use paired eligible samples. Do not report only successful calls as overall reliability. |

## Evidence map and reproduction

All paths below are local to this checkout. Some run artifacts are ignored/untracked: a Git diff
alone is not the complete handoff. Ensure the independent reviewer can access the linked files.
Never include `.env` or credentials in a copied evidence bundle. Call IDs are unique only within
their run directory; always cite the full run path.

| Purpose | Files |
|---|---|
| Current authorities | [AGENTS.md](</Users/alberteinstein/Documents/Projects/AI Audit/AGENTS.md>), [README.md](</Users/alberteinstein/Documents/Projects/AI Audit/README.md>), [PLAN.md](</Users/alberteinstein/Documents/Projects/AI Audit/PLAN.md>), [scoring contract](</Users/alberteinstein/Documents/Projects/AI Audit/eval/SCORING.md>), [format contract](</Users/alberteinstein/Documents/Projects/AI Audit/eval/eval_format_spec.md>) |
| Initial and intermediate narrative | [Probe notes](</Users/alberteinstein/Documents/Projects/AI Audit/docs/openrouter-probe.md>), [development log](</Users/alberteinstein/Documents/Projects/AI Audit/docs/development-logs.md>) |
| Original Pro failure | [Sep 11 probe](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/probe-2026-09-11-r2/probe.json>) |
| First cross-model comparison | [Sep 12 comparison manifest](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/model-comparison-2026-09-12/comparison.json>) |
| Initial prompt/schema results | [Sep 12 run directory](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/prompt-schema-2026-09-12>), [verification](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/prompt-schema-2026-09-12/verification.json>) |
| Earlier H1–H6 design and report | [Proposal](</Users/alberteinstein/Documents/Projects/AI Audit/docs/synthetic-fixture-proposal.md>), [exact fixtures](</Users/alberteinstein/Documents/Projects/AI Audit/spec/diagnostics/hypothesis-fixtures-v1.json>), [results](</Users/alberteinstein/Documents/Projects/AI Audit/docs/experimental-fixture-results-2026-09-15.md>) |
| Earlier execution and grading | [Sep 15 plan](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/hypothesis-fixtures-2026-09-15/execution-plan.json>), [evaluation](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/hypothesis-fixtures-2026-09-15/evaluation.json>), [verification](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/hypothesis-fixtures-2026-09-15/verification.json>) |
| GLM residual failure and comparison | [GLM call-120](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/hypothesis-fixtures-2026-09-15/responses/call-120.json>), [Gemini call-046](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/hypothesis-fixtures-2026-09-15/responses/call-046.json>) |
| Reproduced original Pro abstentions | [Ionstream call-127](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/hypothesis-fixtures-2026-09-15/responses/call-127.json>), [call-133](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/hypothesis-fixtures-2026-09-15/responses/call-133.json>) |
| Deterministic counterfactual | [DeepSeek historical review](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-review-2026-09-15/offline-target-shadow.json>) |
| Latest D/C definitions and report | [Reviewed proposal](</Users/alberteinstein/Documents/Projects/AI Audit/docs/interface-boundary-fixture-proposal.md>), [exact JSON fixtures/prompts](</Users/alberteinstein/Documents/Projects/AI Audit/spec/diagnostics/interface-boundaries-v1.json>), [results](</Users/alberteinstein/Documents/Projects/AI Audit/docs/interface-boundary-results-2026-09-16.md>) |
| Latest frozen execution | [Plan](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/execution-plan.json>), [exact requests](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/requests.json>), [evaluator key](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/evaluator-key.json>) |
| Latest observed outcomes | [11 offline fixtures](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/offline-boundaries.json>), [180-call evaluation](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/evaluation.json>), [raw response directory](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/responses>) |
| Pro concise-prompt failures | [C06 abstention call-091](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/responses/call-091.json>), [C06 abstention call-152](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/responses/call-152.json>), [C06 truncation call-032](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/responses/call-032.json>), [C05 truncation call-085](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/responses/call-085.json>) |
| Matching Pro B0 observations | [C06 call-031](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/responses/call-031.json>), [C06 call-092](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/responses/call-092.json>), [C06 call-151](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/responses/call-151.json>), [C05 call-086](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/responses/call-086.json>) |
| Flash service-error example | [call-003](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/responses/call-003.json>) |
| Latest provenance/isolation | [Verification](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/verification.json>), [launch attestation](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/launch-attestation.json>), [isolation checks](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/responses/isolation.json>), [55-test log](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/local-tests-final.txt>), [endpoint metadata](</Users/alberteinstein/Documents/Projects/AI Audit/runs/milestone2/interface-boundaries-2026-09-16/metadata>) |
| Boundary implementation and tests | [Experimental boundary](</Users/alberteinstein/Documents/Projects/AI Audit/tools/experiments/interface_boundary.py>), [boundary tests](</Users/alberteinstein/Documents/Projects/AI Audit/tests/test_interface_boundary.py>), [evaluation test](</Users/alberteinstein/Documents/Projects/AI Audit/tests/test_interface_evaluation.py>) |
| Execution/evaluation implementation | [Preparation](</Users/alberteinstein/Documents/Projects/AI Audit/tools/experiments/prepare_interface_run.py>), [worker](</Users/alberteinstein/Documents/Projects/AI Audit/tools/experiments/interface_worker.py>), [offline evaluator](</Users/alberteinstein/Documents/Projects/AI Audit/tools/experiments/evaluate_interface_run.py>), [shared raw-output classifier](</Users/alberteinstein/Documents/Projects/AI Audit/tools/experiments/evaluate_fixtures.py>) |
| Existing production-side contract | [Downstream validator](</Users/alberteinstein/Documents/Projects/AI Audit/src/hkex_audit/pipeline_contracts.py>), [its tests](</Users/alberteinstein/Documents/Projects/AI Audit/tests/test_pipeline_contracts.py>), [runtime isolation tests](</Users/alberteinstein/Documents/Projects/AI Audit/tests/test_runtime_isolation.py>) |

The frozen fixture JSON still contains its original provisional status and pre-execution V4.1
discovery text. Do not edit hashed source evidence to update history: approval/execution and
observed V4.1 conformance are recorded by the dated plan/report. Similarly, old reports' integration
status describes their dates. Use current authorities for new implementation decisions.

Safe offline checks, from the repository root:

```sh
make evidence-check
tools/eval-format-tools/.venv/bin/python -m unittest discover -s tests -p test_interface_boundary.py -v
PYTHONPATH=tools/experiments tools/eval-format-tools/.venv/bin/python tools/experiments/evaluate_interface_run.py runs/milestone2/interface-boundaries-2026-09-16
```

The last command re-evaluates saved records without calls or writing new results. Request manifests
encode exact bodies in `body_base64`; response files encode bounded raw bodies in `response_base64`.
Join records to the evaluator key by run-local call ID; verify SHA-256 before drawing conclusions.
Do not rerun the dated preparation script in place: it uses fixed run/staging paths and exclusive
creation. A new live experiment needs a new frozen plan, output directory and reviewed scope.
