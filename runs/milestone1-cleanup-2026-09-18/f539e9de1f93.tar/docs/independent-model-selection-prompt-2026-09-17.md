# Handoff prompt: independent API model selection

You are an independent agent evaluating the best model configuration for the semantic stages of
an HKEX annual-report audit proof of concept. Work in:

`/Users/alberteinstein/Documents/Projects/AI Audit`

Inspect the actual repository, verify existing evidence, design and execute the smallest useful
bounded API comparison, and deliver a justified selection decision. Challenge earlier conclusions.
A conditional recommendation or “no candidate is sufficiently validated” is acceptable. Your task
is model evaluation, not deployment or construction of a new evaluation platform.

## Owner direction and candidate group

**Prefer a Flash model as the normal path if it is sufficient for the real task. Use Pro models
primarily for a measured fallback or debugging role.** This is a preference conditional on evidence,
not permission to trade away necessary correctness. Do not assume Pro beats Flash: release dates,
generations, training and serving configurations differ. An older Pro may be less suitable than a
newer Flash. Names, release order, size and general benchmark rankings are not task-performance
measurements. Evaluate every listed candidate rather than screening solely by its branding.

Use OpenRouter APIs for this PoC. Ignore local hosting, GPU sizing, quantization deployment,
weight downloads and self-hosted serving. Do not spend this investigation on those topics. Record
any material API-use constraint, but do not build a local-model licensing or infrastructure study.

| Candidate supplied by the owner | OpenRouter ID to verify |
|---|---|
| Kimi K3 | `moonshotai/kimi-k3` |
| GLM-5.3 | `z-ai/glm-5.3` |
| Qwen3.8 2.4T A95B (open variant of Qwen3.8 Max) | `qwen/qwen3.8-2.4t-a95b` |
| DeepSeek V4 Pro 0813 | `deepseek/deepseek-v4-pro-0813` |
| DeepSeek V4 Flash 0731 | `deepseek/deepseek-v4-flash-0731` |
| MiniMax M3 | `minimax/minimax-m3` |
| DeepSeek V4.1 Flash | `deepseek/deepseek-v4.1-flash` |
| GLM-5.3 Flash | `z-ai/glm-5.3-flash` |

These are supplied labels/IDs, not independently verified availability, architecture or release
claims. Verify exact identifiers, available routes, supported parameters and current API pricing
from fresh official metadata. If an ID is absent or cannot be served, preserve that observation;
do not silently substitute another version. Keep the two DeepSeek Flash generations distinct.

Repository guidance currently designates DeepSeek Pro. This evaluation explicitly permits comparing
alternatives and recommending a Flash-first policy; Pro receives no scoring advantage. Do not change
the repository's deployment designation or wire a winning model into production in this task.

## Oracle: Gemini-3.8, not DeepSeek Pro

**Gemini-3.8 is the external model oracle. DeepSeek Pro is a candidate, never the oracle.** The
historical oracle ID is `google/gemini-3.8-flash`. Verify that exact variant/route and served identity;
if “Gemini-3.8” requires a materially different variant, make the distinction explicit rather than
inventing an identifier or substituting a generation. If unavailable, report the oracle comparison
as unavailable. Gemini is outside the deployment candidate ranking unless the owner adds it.

An oracle is a comparison reference, not ground truth. Review source-supported expectations before
seeing fresh candidate answers and freeze them. Give Gemini the same bounded source evidence and
operation contract, without candidate outputs or evaluator labels. Score source-backed correctness
and candidate–oracle agreement separately. Resolve disagreements against the source and task
contract, preserving unresolved cases. Do not use majority vote, self-confidence, Pro's answer,
or Gemini's explanation as proof. Keep any diagnostic/adjudication conversation separate from the
initial scored oracle response.

## Pipeline context: what the models actually need to do

The intended lifecycle is ingest → interpret → verify → findings → evaluate → iterate. The current
implementation has an evidence layer and experimental semantic paths, not a completed production
audit pipeline. Native MinerU exports and saved evidence IR already exist; OCR is replaceable and
out of scope. Never read raw PDFs, run OCR, or assess OCR accuracy here.

Models interpret concepts, roles, contextual associations and supported relationships in bounded
selected evidence. Code performs financial parsing, exact-decimal arithmetic, ID/scope validation
and deterministic checks. Models must not produce financial amounts, computed answers, corrected
source values or arbitrary executable plans. Selecting rows because their amounts balance is
forbidden. Use literal source IDs and reusable relationships, not issuer-specific exceptions.

The currently tested operation is `select_direct_addends`: identify a target's nearest direct
contributors, with supporting source IDs, or abstain for missing/ambiguous/incompatible evidence.
Real capability requirements include distinguishing direct children from grandchildren and memo
rows; resolving linked headers and notes; checking entity/consolidation, period, currency/unit and
presentation basis; recognizing incomplete source evidence; and preserving relevant uncertainty.
A syntactically valid selection is not necessarily semantically justified. A supported abstention
is a success, not a reason to force an answer. Easy lexical “find the total” tests are interface
controls, not sufficient evidence for these accounting relationships or future cross-note matching.

## Read and independently verify the evidence

Read `AGENTS.md`, relevant `README.md` and `PLAN.md` sections, `eval/SCORING.md`,
`eval/eval_format_spec.md`, and `spec/evidence-contract.md`. Then read, in order:

1. [Independent-review handoff](model-interface-independent-review-handoff-2026-09-16.md).
2. [Independent review](model-interface-independent-review-2026-09-17.md).
3. [Direct-contributor fixture proposal](direct-contributor-fixture-proposal-2026-09-17.md).
4. [Original executed results](direct-contributor-results-2026-09-17.md).
5. [V2 persistence fix and contract](direct-contributor-persistence-fix-2026-09-17.md).
6. [First connected live v2 results](direct-contributor-live-v2-results-2026-09-17.md).

Follow links to frozen plans, exact requests, raw responses, evaluator keys and implementation.
Replay saved evaluations and check hashes. Ignored/untracked artifacts exist; inspect the filesystem.
Historical evidence to verify, not conclusions you must accept:

- Explicit task wording beat the concise prompt on the narrow September 16 Pro lexical sample.
  Retain explicit operation scope as a starting point; do not transplant “context unnecessary”
  lexical wording into relationship interpretation.
- Existing V4 Flash's 60 Fireworks HTTP 429s left that comparison unassessed. V4.1 results cannot
  fill those missing observations. Provider availability and semantic competence are different.
- The 42-attempt Pro direct-contributor run had 31 full passes, one wrong relationship, five
  timeouts and five truncations. S11 ambiguous group/company scope had one wrong selection and
  two truncations; S08 period conflict had no usable answer. All seven positive cases passed 3/3.
- V1 had a late-write defect: valid leftover result bytes could replay as success after dispatch
  reported persistence failure. V2 requires a hash-bound completion record. Its 42 write-fault
  cases passed; historical v1 remains unchanged and must not be used as the new completion ledger.
- The first connected live v2 run made 15 HTTP requests. All 14 ordinary terminal outcomes committed
  and replayed: S03 selection and S04 abstention were correct, while twelve cases received upstream
  shared-pool 429s. The additional late-write probe also received 429 and correctly replayed as
  incomplete. Successful live-answer-plus-late-write injection remains untested. The suite then
  had 77 passing tests. Neither this nor the two usable answers establishes production readiness.
- The 14 direct-contributor fixtures are authored logical evidence, not production IR. Their prior
  expectations received same-agent review, not independent human adjudication. They are exposed
  development examples. Prior Pro failures remain relevant despite later plumbing improvements.

## Define sufficiency and compare fairly

Evaluate **model + provider + prompt/schema + inference budget**. Record requested and observed
identities, route and supported controls. Do not attribute a route failure or output cap to model
weights. Use an available provider per candidate when necessary, but freeze and disclose routes;
do not trap a candidate on a known failing provider or hide route changes as retries.

Before calls, state the questions, source-backed acceptance criteria, sampling/order, repetitions,
and total call/token/time/cost ceilings, including oracle and diagnostic calls. Production error
budgets are not set: do not invent them or label exploratory thresholds owner-approved. Provide
conditional sufficiency judgments and tradeoffs when a business threshold is missing. Do not
choose a weighted winner score after seeing results.

Use a small staged design: availability/capability checks, a common task comparison across the
servable candidates, then confirmation of plausible default/fallback choices. Predeclare advancement
rules and separate screening from confirmation. Avoid a large full factorial exercise. Count every
probe, failed call and tuning attempt. Bound rate-limit probes; preserve unavailable status rather
than spending the comparison repeatedly on 429s. No schedule or autonomous future retry is needed.

Start from one common explicit task contract, evidence payload and output vocabulary. Keep fresh
conversations and counterbalance order to reduce time/provider confounding. Native API controls may
differ; document those differences. A common output-token cap can disproportionately constrain
reasoning-heavy models. Separate the common-budget result from any justified candidate-specific
budget arm, with equal predeclared tuning opportunities and costs. Freeze tuned settings before
confirmation. Never compare a tuned favorite against untuned rivals or select only the best repeat.

Primary outcomes: supported relationship selection, correct versus unnecessary abstention,
unsupported selection, context/support fidelity, valid contract output and useful completion.
Also report latency, cost and operational availability. Show all-attempt denominators and usable-
answer conditional results. Keep refusal, malformed output, truncation, timeout and HTTP/service
failure distinct; none is silently recoded as semantic abstention or repaired into a scored pass.
Small samples support a provisional decision, not market-wide claims or reliable tail estimates.

## A harder test only when overhead is minimal

First map existing tests to the actual capability requirements above. **Add a harder test if and
only if it provides a material missing distinction with minimal overhead.** Do not turn model
selection into a new benchmark, IR integration project, annotation campaign or evaluation framework.
If that condition is not met, document the gap and proceed with a bounded conclusion.

A useful small option is one or two contrastive pairs (at most four new cases) using the existing
payload and validator: resolve a compact linked note/header structure with two plausible same-label
candidates, a nested subtotal and an included memo row. One case should have enough distributed
source evidence to justify a unique selection; its paired case changes just one required context
link or removes one essential occurrence, requiring abstention or a different supported selection.
Prefer a realistic evidence arrangement over prose that directly states the exact answer list.
Hardness must come from source-grounded relationships, not obscure trivia, artificial token volume,
missing clues that make the answer unknowable, or arithmetic assigned to a model.

Choose only the dimensions a tiny test can genuinely isolate. Reuse selected saved-IR fragments
only if the existing adapter/context tools make it straightforward and expectations can be checked
without PDFs, clean-counterpart oracles or evaluation answers. Otherwise use clearly labeled new
synthetic fixtures. Do not pretend a new synthetic case proves real-IR integration. Freeze source
hashes and reviewed expectations before candidate outputs; keep it out of tuning. Preserve any
ambiguity you cannot adjudicate. Cheap ID/order/distractor or amount-invariance variants may help,
but correlated transformations are not independent accuracy samples.

## Ask for explanations after abstention, refusal or wrong answers

After an initial response has been frozen and scored, make one bounded diagnostic follow-up when
the model produced an abstention (including a correct one), refusal, or wrong answer (WA, determined
by the source-backed evaluator). Predeclare a diagnostic budget; if every qualifying response cannot
be covered, predeclare a representative sampling rule and report all omitted cases. Apply the rule
fairly across candidates and the oracle. HTTP errors, timeouts and empty/truncated responses are not
completed decisions to explain; record them as unavailable diagnostics rather than inventing an
explanation. Respect actual safety refusals; do not attempt to bypass safeguards.

Use the original task/evidence and original response, in a separate diagnostic conversation or
saved continuation. Do not supply the expected answer, announce a WA label, or reveal candidate/oracle
alternatives in the first explanation request. The scored output contract required IDs only, so use
a separate diagnostic schema that allows a brief explanation. For example:

> This is a diagnostic follow-up about your previous response, not a request to change it.
> Give a brief, source-grounded explanation of that response. Cite the literal evidence IDs and
> short source excerpts that support the selection, abstention or refusal. Identify any decisive
> missing evidence, conflicting context, instruction ambiguity, or output-format constraint.
> If you can now identify a specific unsupported assumption or error, state it plainly; otherwise
> say what remains uncertain. Name the smallest clarification or additional evidence that could
> resolve the issue, if applicable. Do not invent source facts, calculate financial amounts, or
> supply a replacement answer. Provide a concise explanation, not private step-by-step reasoning.

Keep follow-up requests/responses, cost, latency and parent-attempt IDs separately. They never
replace the initial answer or change its score. Model self-explanations can be post hoc and wrong;
check cited IDs/excerpts and treat explanations as hypotheses for controlled tests, not causal
proof. Any later correction, expected-answer reveal, or prompt/budget ablation is a new labeled
experiment, not a free second chance. Keep follow-up text and evaluator feedback outside runtime
inference and outside subsequent confirmation prompts.

## Evaluate a default and a realistic fallback policy

Recommend the best sufficient Flash configuration when supported. If none is sufficient, say so
and explain whether a non-Flash default is provisionally necessary or no choice is validated.
For fallback/debugging, compare candidates empirically; do not reserve that role for incumbent Pro
by assumption. It is also valid to recommend no automatic fallback yet.

Fallback triggers must be observable at runtime: for example a contract failure or a documented
kind of unresolved interpretation. Correct abstention due to genuinely missing source evidence is
not cured by asking a larger model to guess. A benchmark-only WA label is not an available runtime
trigger, and a schema-valid wrong answer may remain undetected. Do not claim a cascade catches
those errors unless a separately tested mechanism detects them.

If proposing an automatic cascade, measure it using predeclared observable triggers: useful coverage,
unsupported selections introduced or corrected, unresolved cases, extra cost and added latency.
Distinguish reliability fallback after a service error from semantic fallback after an answer.
Do not simply combine each model's best per-case answer or route using gold labels. Explanation
follow-ups are debugging evidence, not a required production stage unless separately justified.

## Execute through verified, isolated tooling

Use new immutable run directories. Reuse the v2 attempt contract, not v1 result-only replay.
Relevant starting points:

- [V2 dispatcher](../tools/experiments/direct_contributor_attempt_v2.py).
- [Connected live adapter](../tools/experiments/direct_contributor_live_v2.py).
- [Live verifier/evaluator](../tools/experiments/evaluate_direct_contributor_live_v2.py).
- [V2 persistence regressions](../tests/test_direct_contributor_persistence_v2.py).

The current live adapter is explicitly hardcoded to Pro/Fireworks and fifteen attempts; the evaluator
is tied to its prior run. They are references, **not a generic multi-model runner**. Create a new
version/configurable wrapper with candidate identity, schema/parameter capability handling and
verified request binding. Preserve frozen modules/run hashes. Validate the small extension offline
and with isolation preflight before paying for a batch. Do not spend effort reimplementing the
entire harness or weakening assertions to make candidates pass. If schema support differs, report
native contract support separately and use a labeled common-output-contract arm where justified.

Runtime receives only selected evidence and requests, never evaluator keys, expected contributor
sets, benchmark mappings, raw injector metadata or clean counterparts. Verify file-access denials,
not imports alone. Keep raw source, annotations, transport responses, caller outcomes, completion
records, evaluation and diagnostic explanations separate. Persist exact request/response hashes,
prompt/schema/code versions, route, served identity, usage, elapsed time, reported and missing cost.
Resolve `commit_unknown` with read-only replay; never automatically resend an ambiguous attempt.
A committed result can be a refusal or failure; completion is not semantic success.

Read credentials from `OPENROUTER_API_KEY`. The owner previously authorized root `.env` bootstrap
if the process variable is absent. Load only that key into the worker environment; never print it,
put it in prompts/configuration/logs, or pass it in command-line arguments. Worker `.env` reads must
remain denied. Preserve raw corpus inputs, historical artifacts and unrelated working-tree changes.
No raw PDFs, OCR work, model-weight downloads or local hosting are authorized by this task.

## Deliverables

Deliver a concise report with reproducible artifacts, not just a leaderboard:

1. Exact tested candidate and Gemini oracle configurations; unavailable/excluded candidates and
   verified identities/capabilities. Link the frozen design, limits, hashes and any deviations.
2. A capability-to-test map, including whether the minimal harder-test condition was met and why.
   Distinguish old exposed fixtures, new confirmation cases, logical fixtures and genuine saved IR.
3. A results table with explicit numerators/denominators: correct selections, correct/unnecessary
   abstentions, unsupported selections, invalid outputs, refusals, truncations, timeouts and service
   errors. Separate source correctness, oracle agreement, support fidelity and completion.
4. Cost/latency and failure accounting, plus source-backed disagreement examples. Summarize what
   explanation follow-ups suggested, what independent evidence supports, and what remains speculation.
5. A recommendation for default, fallback and debugging roles, with measured tradeoffs, sufficiency
   limits, unobservable failure modes and the smallest next experiment that could change the decision.

Finish with an explicit model-choice verdict and an evidence-sufficiency verdict. Update concise
development notes with significant discoveries. Do not deploy, change the production designation,
mark the pipeline complete, or manufacture a winner merely because the comparison finished.
