# Implementation Plan

**Status: proposed; all milestones are pending.** Implements [README.md](README.md).
The initial design is preserved in [README.original.md](README.original.md).

## 1. Delivery and ownership

Build a thin complete lifecycle first, then extend coverage across all six scored categories.
Use one extractor adapter, DeepSeek-V4-Flash for semantic interpretation, deterministic verification,
and a batch runner that persists evidence, annotations, comparison plans, and results.

Milestones are ordered by dependency. Extraction and audit teams can work independently after the
first contract is agreed, but both participate in the first end-to-end milestone.

| Area | Owner | Handoff |
|---|---|---|
| Evidence schema and validators | Audit team with extraction-team input | Versioned contract and representative examples |
| Extractor, adaptation, licenses, adapter | Extraction team | Native output, conforming evidence, capability report, manifest |
| Interpretation, planning, verification | Audit team | Validated annotations/plans, findings, coverage |
| Accounting correctness of fixtures | Domain reviewer with audit team | Reviewed development contexts and relationships |
| Scoring and held-back data | Evaluation owner | Confirmed contract, split, frozen configuration, scored report |

## 2. Milestone 0 — Intake and evaluation boundaries

- [ ] Confirm the clean report, original/extended injections, distractors, and taxonomy.
- [ ] Confirm the referenced `eval/SCORING.md` version and implementation requirements; do not
  silently change a frozen contract.
- [ ] Validate `site_id`, `injection_stage`, `original_value`, units/precision, propagation metadata,
  and retained descoped records. Record missing fields and owners.
- [ ] Assign development/held-back splits by site, grouping related variants and propagation cases.
- [ ] Keep held-back answers and counterparts out of detection development and fixture authoring.
- [ ] Fix and date `ALERT_BUDGET` and alert counting/grouping rules before a scored run.
- [ ] Confirm the initial extractor/version, dependency/weight licenses, and manifest requirements.
- [ ] Identify the actual hosted model revision and intended internal serving configuration;
  record any pinning limitation and its resolution path.

**Exit:** intake status and scoring blockers have named owners. Development work can proceed on
eligible data while independent intake items are unresolved; headline publication cannot.

## 3. Milestone 1 — Evidence contract and fixtures

- [ ] Define evidence records for pages, blocks, logical tables/cells, raw text, recovered spans,
  source references, manifest, capabilities, and unresolved regions.
- [ ] Specify coordinates, rotation, physical page indexing, and printed page labels separately.
- [ ] Keep cell/character geometry optional and report actual localization granularity.
- [ ] Define annotation, comparison-plan, and result records with supporting references/prerequisites.
- [ ] Implement schema, reference, and span validators without fabricating missing capabilities.
- [ ] Build reviewed development fixtures for a primary statement, roll-forward, merged/continued
  table, statement-to-note pair, token/reference examples, and deliberate ambiguity.
- [ ] Implement one adapter; preserve its native output unchanged.
- [ ] Inspect a few second-engine samples against the contract; add another adapter only if needed.
- [ ] Establish literals/import-boundary checks and a scoring harness skeleton.

**Exit:** validated evidence retains unresolved regions and traceable source occurrences. Extraction
accuracy is inspected against the page independently of schema validity. Both teams review the handoff.

## 4. Milestone 2 — Complete lifecycle on representative cases

- [ ] Parse numbers with exact decimals, raw-text preservation, parse status, and precision.
- [ ] Resolve explicit dates/units/scopes and known vocabulary deterministically.
- [ ] Add DeepSeek labelling for remaining concepts/roles/links with bounded context, identifier-only
  outputs, validation, bounded retries, and explicit failure handling.
- [ ] Cache responses by full context/model/prompt/schema/configuration identity; keep reviewed lexicon
  entries separate and disable learning during evaluation.
- [ ] Construct signed-sum and compatible-equality plans from supported evidence and patterns.
- [ ] Add token/reference checks that can execute directly on evidence.
- [ ] Implement interval tolerances, local prerequisite states, and execution-failure records.
- [ ] Produce findings, abstentions, attempts, coverage, and a simple table.
- [ ] Run frozen-IR and PDF-to-findings paths, explicitly distinguishing their claims.

**Exit:** one command completes extraction → annotations → plans → checks → findings → diagnostic
evaluation. Every finding is traceable. Deliberate ambiguity abstains. Saved-artifact replay produces
identical downstream results. The examples expose failures as well as successful detections.

**Decision point:** re-estimate effort from observed extraction, semantic, and planning gaps before
expanding category coverage. Fix inadequate contracts here rather than compensating inside checks.

## 5. Milestone 3 — Arithmetic and contextual consistency

- [ ] Extend additive, reconciliation, matrix, comparative, and maturity patterns as required by fixtures.
- [ ] Implement primary-statement and internal-note checks over these patterns.
- [ ] Distinguish memo rows, nested subtotals, transfers, missing contributors, and contribution signs.
- [ ] Preserve instant/duration, group/parent, currency/scale, and restatement/presentation distinctions.
- [ ] Implement document-wide consistency within supported contexts; retain duplicate source occurrences.
- [ ] Validate rounding assumptions on clean development examples without widening tolerance to hide alerts.
- [ ] Verify that changing amounts does not change structurally justified operand selection.

**Exit:** supported plans have reviewed, complete relationships; unsupported cases abstain. Failure
in both comparative periods does not automatically invalidate a plan. Coverage and misses are visible.

## 6. Milestone 4 — References, typography, and statement-to-note links

- [ ] Build note and printed-page indexes while preserving literal references.
- [ ] Implement dangling references and supported semantic-reference compatibility checks.
- [ ] Implement raw-token formatting checks with declared evidence needs; do not infer glyph details
  from normalized text when fine-grained evidence is unavailable.
- [ ] Match statement lines to note facts through concept/context filtering and bounded ID selection.
- [ ] Add bounded alternative-note search for suspicious references without silent replacement.
- [ ] Exercise ambiguity, wrong-but-existing notes, restated comparatives, and multiple candidate totals.
- [ ] Describe failed relationships as inconsistencies unless evidence identifies the wrong cell.

**Exit:** all six scored categories have implemented paths, positive/benign examples, and explicit
abstention conditions. Matching never selects a fact merely because its amount agrees.

## 7. Milestone 5 — Generalization and reproducibility

- [ ] Complete the six invariance transforms with mappings for equivalent IDs, locations, and units.
- [ ] Apply scoring-contract exemptions; compare equivalent findings after mapping rather than raw bytes.
- [ ] Distinguish IR-only transformations from PDF-level extraction tests.
- [ ] Add randomized synthetic values and controlled corruptions with related variants grouped in splits.
- [ ] Probe a few second-issuer tables separately. Record vocabulary/pattern additions, coverage, and any
  check-code changes. Do not present this as market-wide calibration.
- [ ] Verify literals/import boundaries and absence of runtime evaluation-data access.
- [ ] Compare semantic fixtures on the intended internal serving setup when available; otherwise report
  parity as unverified, not established by API compatibility.
- [ ] Exercise missing/truncated/invalid model responses and unknown IDs with bounded failure handling.

**Exit:** declared invariance/literals gates pass and extraction limitations and parity evidence are
explicit. Changes found here are validated before the final configuration freeze.

## 8. Milestone 6 — Frozen evaluation and handoff

- [ ] Freeze code/configuration, prompts, lexicon, patterns, model identity, extractor, and manifests.
- [ ] Verify matching against the contract: duplicates, neutral descoped matches, detectability bands,
  misses, exemptions, and denominators.
- [ ] Run clean/corrupted PDF paths with identical extraction settings for applicable injection stages.
- [ ] Evaluate held-back data without tuning on its outcomes or updating the lexicon.
- [ ] Report banded recall, coverage, misses, clean alerts per 100 pages, and cluster-bootstrap
  uncertainty with `n_records` and `n_sites`.
- [ ] Withhold headline recall unless all required gates pass; preserve failed-run diagnostics.
- [ ] Deliver replay artifacts, source-to-finding examples, the extraction handoff, coverage gaps,
  and a measured extension-effort estimate.

**Exit:** complete lifecycle demonstrated with reproducible evidence and bounded claims. If held-back
results trigger more development, record the exposure and version the next evaluation round; the
same data is no longer an untouched holdout.

## 9. Verification and effort discipline

Prioritize tests where silent errors affect audit outcomes: spans/references, numeric parsing,
context compatibility, contributor completeness, rounding boundaries, wrong-note selection, missing
evidence, neutrality, leakage, and invariance. Use reviewed fixtures and meaningful synthetic properties.

The first scope is one adapter, one batch runner, the chosen semantic model, simple artifacts, and
six categories. Add OCR fallbacks, fine-tuning, storage infrastructure, or adapters only when measured
failures justify them. Broader issuer coverage and calibration follow the PoC.

Re-estimate after milestone 2. Record audit-team effort, extraction-team effort, and integration
waiting time separately; parallel ownership does not eliminate work. The original estimate is a
historical reference rather than a commitment under the revised design.
