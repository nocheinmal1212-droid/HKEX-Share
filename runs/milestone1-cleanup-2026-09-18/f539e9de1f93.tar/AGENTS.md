# Working on HKEX Annual Report Audit

Adapted from [AGENTS_template.md](AGENTS_template.md). Applies throughout this repository.
Optimize for the user's intended outcome and verified behaviour. Scale investigation, planning,
verification and notes to the uncertainty and consequences of the task; these practices are tools,
not a checklist to execute for every change.

## Goals, constraints and implementation freedom

Build a proof of concept demonstrating the complete lifecycle: ingest → interpret → verify →
findings → evaluate → iterate. Prioritize working, traceable results and generalization by design.

Distinguish explicit requirements from assumptions and provisional implementation choices.
The user's instructions take precedence over repository guidance. Preserve these project constraints
unless the user changes them:

- Keep extraction, evidence, semantic interpretation, comparison planning, verification and
  evaluation cleanly separated. The extraction model must remain replaceable.
- Use code for financial parsing and arithmetic. Models interpret concepts, roles and links;
  they do not supply financial amounts, computed answers or corrected source values.
- Follow the provisional model policy in [README section 4](README.md#4-model-operation-and-licensing):
  Gemini 3.8 Flash is primary; DeepSeek V4.1 Flash receives the same bounded semantic queries for
  research only. Both use OpenRouter. Only validated Gemini responses may affect audit decisions;
  no automatic fallback is selected. Integration remains pending; model selection is closed.
  Read credentials from `OPENROUTER_API_KEY`, never prompts, logs or tracked configuration.
- OCR selection is separate; MinerU is the first adapter source, not the downstream contract.
  Use existing native outputs. OCR installation/reruns/adaptation/hosting, local language-model
  hosting and weight downloads are outside current scope. Training a new model is outside this PoC.
- Generalize through reviewed vocabulary and reusable relationships. Do not hard-code issuer
  names, note numbers, benchmark amounts or fixed cell positions into detector logic.
- Respect the licensing constraint in README.md for code, weights and transitive dependencies.
  An adapter or process boundary alone does not establish compliance.
- Keep PoC scope: one batch application, a first adapter, saved artifacts and a simple findings
  view. Add services, storage systems, fallbacks or fine-tuning only when measured needs justify them.
- Use English for code, documentation and prompts; preserve original Chinese source text literally.

Architecture details, module layout, algorithms and milestone sequencing remain provisional.
Revise them when evidence warrants it without repeatedly seeking permission for routine choices.
Ask only when materially different intended outcomes remain unresolved or an explicit constraint
must change. Continue unaffected authorized work while awaiting a decision.

**Model-policy precedence (2026-09-18):** the owner-approved [reconciliation](docs/model-policy-reconciliation-2026-09-18.md)
supersedes older Pro-only designations and candidate-selection recommendations. If an overlooked
instruction conflicts, follow README section 4, record the discrepancy and reconcile active guidance.
Preserve frozen experiments and historical claims. Gemini is not ground truth; research outputs
must remain outside operational annotations, plans and findings. Do not infer integration or
production readiness from this documentation decision.

## Read the current authorities

Read the documents relevant to the task before changing their contracts. Avoid copying detailed
rules into new files that could become competing sources of truth.

| Authority | Owns |
|---|---|
| [README.md](README.md) | Objectives, constraints and proposed architecture |
| [PLAN.md](PLAN.md) | Milestones, ownership, implementation status and exit criteria |
| [eval/SCORING.md](eval/SCORING.md) | Scoring scope, matching, metrics and publication gates |
| [eval/eval_format_spec.md](eval/eval_format_spec.md) | Canonical records, provenance, mappings and migration |
| [spec/taxonomy.yaml](spec/taxonomy.yaml) | Single nine-code category vocabulary |
| [schemas/taxonomy.schema.json](schemas/taxonomy.schema.json) | Taxonomy validation |

The taxonomy's active status does not imply a scored or implemented detector. Use SCORING.md for
the six-category scope; do not recreate a separate six-code taxonomy or add descoped detector work.

README.original.md and docs/archive/ are historical references, not current instructions.
Inspect the actual filesystem and implementation status: planned paths do not prove code exists.
The existing tools/eval-format-tools package has legacy assumptions; establish version-2
compatibility before using it on canonical data. An empty discovery or formatting pass is not
evidence of schema validation, working CI or a functioning audit pipeline.

Resolve inconsistencies explicitly with the owning contract. If an authorized change affects
contract semantics, update the affected documentation/schema and version or migration notes
together; never silently reinterpret a frozen scoring run. Preserve historical evidence.

## Protect source evidence and evaluation boundaries

Treat supplied PDFs, raw injection metadata and native extractor outputs in corpus/ as immutable
inputs. Write adapters, canonical records and derived artifacts separately. Do not reformat raw
files, overwrite exports, or silently repair extracted values. Preserve source IDs, text and hashes.
Respect unrelated user changes in the working tree.

Use existing native outputs and saved evidence IR for detector development. Avoid raw-PDF reads
unless a material question cannot be resolved from native artifacts and existing review evidence;
record why the targeted inspection is necessary. Do not install or run OCR to fill gaps. Keep
unknowns explicit and dependent checks abstained. Clean and corrupted artifacts are separate runs;
a corrupted run must not read the clean export or IR as an oracle. The injector metadata is for
evaluation intake and validation, even though gitignored; gitignore does not enforce runtime isolation.

Runtime detection receives explicitly selected inputs, not unrestricted corpus globs.
corpus/error_detail.jsonl is ground truth despite sitting beside PDFs. Keep evaluation records,
source mappings, split labels and benchmark-authored operand lists out of runtime detection and
prompt construction. Never use the clean counterpart as an oracle for the corrupted report.
Evaluation preparation may inspect these sources within its authorized scope.

Keep pending intake distinct from ready records and active/retired lifecycle. Unknown geometry,
precision, seeds, checkpoints or settings remain unknown with reasons; do not invent defaults.
Confirm physical page numbering, printed labels, coordinate conventions and source correspondence.
Matching extractor version strings do not establish equivalent settings or identical source PDFs.

Follow the scoring contract's site and split-group rules before detector tuning. Do not reroll
splits, tune on held-back outcomes, or hide prior exposure. Keep evaluation configuration and
reviewed vocabulary frozen during scored runs.

## Investigate risky assumptions early

For uncertain or consequential work, identify the assumption most likely to invalidate the design.
Use repository evidence, authoritative documentation, a small experiment, an independently checked
calculation or a prototype to resolve it. Plan immediate uncertain work in detail and leave later
details provisional. Resolving uncertainty is progress even without production code.

In this project, investigate extraction fidelity, table completeness, context compatibility,
relationship selection, rounding assumptions and provenance before optimizing detector coverage.
Schema-valid extraction is not necessarily faithful to the PDF; schema-valid model labels are not
necessarily correct. Inspect representative source pages when the claim depends on their appearance.

Prefer existing capabilities when they meet the constraints. Keep extractor-specific imports and
native fields inside adapters so downstream work can run on frozen evidence without MinerU.
The audit team owns the shared contracts; the extraction team owns the engine and conforming adapter.
Use the first handoff to expose contract gaps instead of compensating for them inside every check.

## Preserve meaning through the pipeline

Keep raw evidence, semantic annotations and comparison plans separate and traceable.
Adapters translate evidence without inferring accounting relationships. Preserve distinct source
occurrences, recovered spans and unresolved regions. Cell boxes, fonts and visual hierarchy are
optional capabilities; never fabricate them or discard failures to improve coverage.

Parse financial values with exact decimal arithmetic, separate from raw text. Distinguish blank,
dash, zero, missing content and failed recognition. Preserve concept, entity/consolidation scope,
period, unit/scale and presentation basis; unknown context stays unknown.

Establish relationships from supported roles and context before computing agreement. Do not use
amount similarity, subset-sum search or a balancing result to select operands or matching note facts.
Use bounded model inputs and validated ID/label outputs, with bounded retries and explicit failures.
Plans use permitted operations and source references, never arbitrary model-generated code.

Each check declares its actual evidence needs and local prerequisites. Record relevant blocked
opportunities as abstained; reserve not_applicable for genuinely irrelevant checks. Keep passed,
failed and crashed distinct and retain unresolved opportunities in coverage. A failed equation
establishes an inconsistency, not automatically the guilty cell or its correct value.

## Reconsider the approach during implementation

Reassess when evidence contradicts an assumption, successive fixes fail, special cases or coupling
grow, measured accuracy/performance differs from expectations, or a simpler approach becomes viable.

Identify the affected assumption, compare plausible alternatives and run the smallest useful check
that distinguishes them. Revisit the diagnosis before adding another workaround. In particular,
issuer-specific exceptions, forced cell geometry, widened tolerances and checks that depend on
unrelated detector outcomes are reasons to revisit the design.

Do not replan as a ritual. When attempts stop producing new evidence, change the investigation
strategy or identify the missing information. Update affected plan steps when decisions change.

## Design verification from intended behaviour

Before critical logic, define observable success, boundaries, invalid inputs and failure outcomes.
Derive expected results from domain rules, independently reviewed examples or a trusted reference;
do not generate the implementation and its expected answers from the same unverified reasoning.

Select checks according to risk:

- Use reviewed examples for numeric parsing, context compatibility, contributors and wrong-note
  selection. Check tolerance boundaries and propagated changes, including the total's rounding
  uncertainty under the format contract's stated assumptions.
- Use generated relationships and invariance properties to test generalization. Verify that
  changing amounts does not change structurally justified operand selection.
- Compare complex matching with a simple exhaustive reference on small cases. Exercise ties,
  competing findings, paired endpoints and neutral/excluded populations under SCORING.md.
- Test missing evidence, invalid IDs, malformed responses, retries and partial/whole-run failures.
  Check file access as well as imports when verifying ground-truth isolation.
- Exercise the complete lifecycle when integration changes. Inspect persisted findings and their
  source traces, not just a successful command exit or a displayed table.

For a defect, reproduce it and preserve a regression check where practical. If reproduction is
unreliable, use the strongest available evidence and state the uncertainty. Do not weaken assertions,
widen tolerances, drop cases or change expected results solely to make a patch pass. Correct a test
when independent evidence shows its expectation is wrong, and record that evidence.

Use focused checks during iteration and broader checks after meaningful integration. For critical
logic, consider targeted fault injection to establish that tests reject plausible mistakes.
Routine documentation changes need relevant consistency/link checks, not a new test framework.
Discover actual project commands; do not invent a working build or repeatedly run expensive checks
without a new change, failure or unresolved concern.

## Evaluate and report honestly

Follow SCORING.md rather than inventing convenient metrics. Keep fixture, frozen_ir and
pdf_end_to_end claims distinct. Hand-authored diagnostic annotations cannot substitute for generated
inputs in end-to-end results. Report coverage and failures alongside recall; do not silently remove
unresolved regions or pending records to shrink denominators.

Keep recall bands and non-numeric results separate. Clean alerts measure workload, not automatically
false positives; display grouping must not reduce the raw count. Headline results remain UNGATED
until the contract's intake, isolation, invariance and complete clean-run gates pass. Do not invent
approval for unset budgets or interpret missing gate evidence as success.

Record input/configuration/model identities and limitations. Frozen-artifact replay and fresh
OCR/model calls are different experiments; temperature zero and a mutable alias do not guarantee
reproducibility. One report and a few portability probes do not establish market-wide accuracy.

## Preserve discoveries and finish with evidence

For complex work, keep concise durable notes in [docs/development-logs.md](docs/development-logs.md)
when discoveries will help future work: assumptions, significant observations, failed experiments,
rejected approaches, unresolved questions and the next useful check. Do not copy held-back answers
into general development notes. Routine tasks need no extra log or unrequested planning document.

Before declaring completion, confirm that the chosen approach fits the problem and gather evidence
appropriate to the change. Mark plan items complete only when their stated exit conditions hold.
If required verification cannot run, finish unaffected work and distinguish implementation status
from verification status. Identify the blocker and what remains unverified.

Report concisely what changed, what was actually checked and any material limitation. Passing tests,
model agreement, confidence or a completed checklist alone do not establish correctness.
