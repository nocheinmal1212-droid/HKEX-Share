# Benign fixture preparation

Owner: Project user (interim domain/review owner). Status: planned, no reviewed negative dataset.

Prepare these small, separately labeled fixtures for the first vertical slice:

| Case | Evidence to retain | Expected diagnostic behavior |
|---|---|---|
| Independent displayed rounding | Complete sum, including rounded total and stated units | Pass when residual is within the justified bound |
| Legitimate context difference | Group/parent, period, scale and presentation labels | Do not compare incompatible facts; explain ambiguity |
| Valid note reference | Literal reference and matching note subject | No reference discrepancy |
| Accepted negative style | Locally supported parentheses and minus variants | Do not flag a valid style solely because it differs |
| Valid percentage | Repeated percent conventions and full narrative | Preserve valid token and its unit |
| Deliberate ambiguity | Two plausible targets with insufficient context | Abstain instead of selecting by matching amounts |

Use source-derived development examples only after their frozen-group and owner reviews, or clearly
label manually authored synthetic fixtures as fixture mode. Do not silently count synthetic examples
as PDF end-to-end inputs. Keep known real anomalies separate from false-alert labels.

Injection-artifact inspection found white replacement patches, altered typography and lost title
characters. Before assessing an artifact-only baseline, prepare balanced positive/benign examples
with controlled visual treatment and review their labels. No chance-performance claim is justified.
