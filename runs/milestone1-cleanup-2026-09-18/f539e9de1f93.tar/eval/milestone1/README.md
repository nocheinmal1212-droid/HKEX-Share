# Milestone 1 evidence handoff

Implementation is available; **owner acceptance is pending**. The four ready intake cases have new,
proposed native-to-IR correspondences for both independent document runs. Prior approvals were not
extended to these mappings or to the six new synthetic benign/ambiguous fixture labels.

Open [the review packet](reviews/r1/index.html). Its [review record](reviews/r1/review.json) binds the
exact IR hashes, ready selector, fixture selection and verification evidence. The
[verification summary](reviews/r1/verification-summary.json) records 19 evidence tests, 26 retained
intake tests, full source-backed native/IR checks and installed-wheel replay with the adapter absent.
No detector, model or OCR execution is included. All results remain UNGATED.

The full artifacts are saved locally under `runs/milestone1-r1/` (gitignored). Each variant retains
228 pages, 132 table regions and 6,415 cells. Clean has 129 resolved and 3 partial grids; corrupted
has 128 resolved and 4 partial grids. These are HTML recovery states, not source-fidelity or
accounting-completeness decisions. Native/PDF image descriptions and unsupported inline content
remain visible limitations. No raw PDF or injector-record read was needed for this implementation.

From the repository root:

```sh
make evidence-check
make evidence-local-check
```

The first target uses portable synthetic fixtures. The second verifies the frozen ready selector,
generates native runs independently in a temporary directory, checks every native literal pointer,
repeats ingestion, runs guarded IR-only replay and probes forbidden file access. It does not promote
fixture labels or run the old PDF-reading intake validation command.

To persist a new review revision after an implementation change:

```sh
PYTHONPATH=src:tools/eval-format-tools tools/eval-format-tools/.venv/bin/python \
  eval/milestone1/validate.py --output runs/<new-run>
PYTHONPATH=src:tools/eval-format-tools tools/eval-format-tools/.venv/bin/python \
  eval/milestone1/prepare.py --runs runs/<new-run> --output eval/milestone1/reviews/<new-revision>
```

Use new paths. Never overwrite a reviewed packet or its run artifacts. Approval must name the packet's
content fingerprint and accepted/rejected items; retain the pending packet as historical evidence.
The source inventory, canonical records, frozen split and existing approvals remain unchanged.
